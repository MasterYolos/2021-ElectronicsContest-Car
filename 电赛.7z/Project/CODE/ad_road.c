/****************************************************************
 * @file            ad_road.c
 * @school          �ϲ����մ�ѧ��ʮ����ȫ����ѧ�����ܳ�����˫��������
 * @author          LYF/OREO
 * @version         v2.0
 * @Software        KEIL
 * @Target core     MM32F3277G
 * @date            2021-3-19
****************************************************************/
#include "ad_road.h"
#include "headfile.h"
#include <stdlib.h>
#define 	ElcetMAX_A                 2500      
#define 	ElcetMAX_B                 2000     
#define 	ElcetMAX_C                 2400     
#define 	ElcetMAX_D                 2000      
#define 	ElcetMAX_E                 2500     
#define 	InductanceCount            20     
//��������
int ROUND_SPEED = 124;										//�����ٶ�
int ROUND_GO_FLAG=1;											//�Ƿ����
int ROUND_GO_EVERY=0;											//ѭ������
int ROUND_NUM = 0;												//��������
int ROUND1_DIR =1;  											//��һ�����ķ��� -1 L 1 R
int ROUND2_DIR =-1;												//�ڶ������ķ��� -1 L 1 R
int ROUNDCOLDCOUNT  =	3000;			          //��������ȴ���� 3000
int Round_Threshold =	12500;			        //������м�����ֵ
int Round1_Distance =1000;                //����1���ƾ���
int Round2_Distance =1100;                //����2���ƾ���
int Round_Wait=4000;                      //�Ⱥ����ʱ�� 
int Round_Navdir=1;                       //����������ʽ  1Ϊ�󵥱�Ѳ�� 2Ϊ�ҵ���Ѳ��

//����·�ڲ���
int CrossRoad_Dir					  = 1;					//����������
int CrossRoad_Num           = 0;          //�����ľ�������
int CrossRoad_Angle 				= 30000;			//�ǶȻ�����
int CrossRoad_STOP_DISTANCE = 2000;				//����ͣ������
int CrossRoad_Threshold     = 8200;				//�����������ֵ
int CrossRoad1_Distance     = 2900;       //��һ��������� �ֳ����� 
int CrossRoad_Distance      = 6000;       //�ڶ������������� �ֳ����� ���õĻ����úܴ�
//���복�����
int Park_dir =2;                          //���복�ⷽ�� 1��2��
int Park_Integal_angle =4000;             //���ֽǶȳ�����ֵ
int Out_Park_Navdir=1;                    //����������ʽ 1Ϊ�󵥱�Ѳ�� 2Ϊ�ҵ���Ѳ��
int In_Park_Navdir=1;                     //����������ʽ 1Ϊ�󵥱�Ѳ�� 2Ϊ�ҵ���Ѳ��
float Park_Distance=3200;                 //�������λ��
//�������ݼ�¼����
#define DATA_SIZE		1024/sizeof(uint32)   //���ݳ���
uint32 Integal_data_buffer[DATA_SIZE];    //�������뻺����


int cross2_left=0;
int cross2_right=0;

Road_Integral Road_Integrals;
static Inductance sInductance; 

Inductance *psInductance = &sInductance;
void Round_Processing(float ROUND_DIR);
void three_processing(void);
void Ramp_processing(void);
void Car_Protect(void);
void Out_Parking_Prosses(void);
void In_Parking_Prosses(void);
/*
��ʼ��ADC�ɼ�
*/
void My_ADC_Init(void)
{
	adc_init(ADC_2,ADC2_CH04_A04,ADC_12BIT);
	adc_init(ADC_2,ADC2_CH05_A05,ADC_12BIT);
	adc_init(ADC_2,ADC2_CH06_A06,ADC_12BIT);
	adc_init(ADC_2,ADC2_CH07_A07,ADC_12BIT);
	adc_init(ADC_3,ADC3_CH10_C00,ADC_12BIT);
}
extern void TwoUnNumSwap(uint16 *a, uint16 *b)  
{
  uint16 temp  = *a;
  *a = *b;
  *b = temp;
}

int UnQuickSort(uint16	*array, const int maxlen, const int begin, const int end)  
{  
	
    int i = 0, j = 0;
    if(begin < end)  
    {
        i = begin + 1;  
        j = end;        
        while(i < j)
        {  
            if(*(array + i) > *(array + begin))   
            {  
                TwoUnNumSwap(array + i, array + j);   
                j--;  
            }
            else  
            {
                i++;  
            }
        }
        if(*(array + i) >= *(array + begin)) 
        {  
            i--;  
        }  
        TwoUnNumSwap(array + begin, array + i);  	   
        UnQuickSort(array, maxlen, begin, i);  
        UnQuickSort(array, maxlen, j, end);		
		return true;
    }
	else
	  return false;
}

float InductanceMeasure(Inductance *psInductance)
{
  for(int i=0;i<20;i++)
  {
    psInductance->InductanceNowA[i] = adc_convert(ADC_2,ADC2_CH04_A04);  
    psInductance->InductanceNowB[i] = adc_convert(ADC_2,ADC2_CH05_A05);   
    psInductance->InductanceNowC[i] = adc_convert(ADC_2,ADC2_CH06_A06);  
    psInductance->InductanceNowD[i] = adc_convert(ADC_2,ADC2_CH07_A07);   
    psInductance->InductanceNowE[i] = adc_convert(ADC_3,ADC3_CH10_C00);  
  }
  
  UnQuickSort(psInductance->InductanceNowA,20,0,InductanceCount);
  UnQuickSort(psInductance->InductanceNowB,20,0,InductanceCount);
  UnQuickSort(psInductance->InductanceNowC,20,0,InductanceCount);
  UnQuickSort(psInductance->InductanceNowD,20,0,InductanceCount);
  UnQuickSort(psInductance->InductanceNowE,20,0,InductanceCount);

  for(int i = 7;i <= 14;i++)
  { 
    psInductance->InductanceSumA+=psInductance->InductanceNowA[i];
    psInductance->InductanceSumB+=psInductance->InductanceNowB[i];
    psInductance->InductanceSumC+=psInductance->InductanceNowC[i];
    psInductance->InductanceSumD+=psInductance->InductanceNowD[i];
    psInductance->InductanceSumE+=psInductance->InductanceNowE[i];
  }

  psInductance->InductanceAveNowA = psInductance->InductanceSumA/8;
  psInductance->InductanceAveNowB = psInductance->InductanceSumB/8;
  psInductance->InductanceAveNowC = psInductance->InductanceSumC/8;
  psInductance->InductanceAveNowD = psInductance->InductanceSumD/8;
  psInductance->InductanceAveNowE = psInductance->InductanceSumE/8;

  if(psInductance->InductanceAveNowA>psInductance->InductanceAveMAXA)
    psInductance->InductanceAveMAXA=psInductance->InductanceAveNowA;
  if(psInductance->InductanceAveNowB>psInductance->InductanceAveMAXB)
    psInductance->InductanceAveMAXB=psInductance->InductanceAveNowB;
  if(psInductance->InductanceAveNowC>psInductance->InductanceAveMAXC)
    psInductance->InductanceAveMAXC=psInductance->InductanceAveNowC;
  if(psInductance->InductanceAveNowD>psInductance->InductanceAveMAXD)
    psInductance->InductanceAveMAXD=psInductance->InductanceAveNowD;
  if(psInductance->InductanceAveNowE>psInductance->InductanceAveMAXE)
    psInductance->InductanceAveMAXE=psInductance->InductanceAveNowE;

  if(psInductance->InductanceAveMAXA>ElcetMAX_A)
    psInductance->InductanceAveMAXA = ElcetMAX_A-400;
  if(psInductance->InductanceAveMAXB>ElcetMAX_B)
    psInductance->InductanceAveMAXB = ElcetMAX_B-500;
  if(psInductance->InductanceAveMAXC>ElcetMAX_C)
    psInductance->InductanceAveMAXC = ElcetMAX_C-600;
  if(psInductance->InductanceAveMAXD>ElcetMAX_D)
    psInductance->InductanceAveMAXD = ElcetMAX_D-500;
  if(psInductance->InductanceAveMAXE>ElcetMAX_E)
    psInductance->InductanceAveMAXE = ElcetMAX_D-400;

  psInductance->InductanceGYHA=(float)(psInductance->InductanceAveNowA)/(float)(psInductance->InductanceAveMAXA)*1000;
  psInductance->InductanceGYHB=(float)(psInductance->InductanceAveNowB)/(float)(psInductance->InductanceAveMAXB)*1000;
  psInductance->InductanceGYHC=(float)(psInductance->InductanceAveNowC)/(float)(psInductance->InductanceAveMAXC)*1000;
  psInductance->InductanceGYHD=(float)(psInductance->InductanceAveNowD)/(float)(psInductance->InductanceAveMAXD)*1000;
  psInductance->InductanceGYHE=(float)(psInductance->InductanceAveNowE)/(float)(psInductance->InductanceAveMAXE)*1000;

  psInductance->InductanceSumA=0;
  psInductance->InductanceSumB=0;
  psInductance->InductanceSumC=0;
  psInductance->InductanceSumD=0;
  psInductance->InductanceSumE=0;
  psInductance->flag = (psInductance->InductanceGYHA >= psInductance->InductanceGYHE) ? 1 : 0;
	//dir5ΪAE+BD��Ⱥ�
	psInductance->dir5 = (psInductance->InductanceGYHA >= psInductance->InductanceGYHE) ? \
    (float)(psInductance->InductanceGYHA + psInductance->InductanceGYHB-psInductance->InductanceGYHE - psInductance->InductanceGYHD)/ \
      (float)(psInductance->InductanceGYHA+psInductance->InductanceGYHE+psInductance->InductanceGYHB+psInductance->InductanceGYHD)*100: \
        (float)(psInductance->InductanceGYHE+psInductance->InductanceGYHD-psInductance->InductanceGYHB-psInductance->InductanceGYHA)/\
					(float)(psInductance->InductanceGYHA+psInductance->InductanceGYHE+psInductance->InductanceGYHB+psInductance->InductanceGYHD)*100;
	//dirΪAE��Ⱥ�			
  psInductance->dir = (psInductance->InductanceGYHA >= psInductance->InductanceGYHE) ? \
    (float)(psInductance->InductanceGYHA-psInductance->InductanceGYHE)/ \
      (float)(psInductance->InductanceGYHA+psInductance->InductanceGYHE)*100: \
        (float)(psInductance->InductanceGYHE-psInductance->InductanceGYHA)/(float)(psInductance->InductanceGYHA+psInductance->InductanceGYHE)*100;
	//dir2ΪAD��Ⱥ�		
 psInductance->dir2 = (psInductance->InductanceGYHA >= psInductance->InductanceGYHD) ? \
    (float)(psInductance->InductanceGYHA-psInductance->InductanceGYHD)/ \
      (float)(psInductance->InductanceGYHA+psInductance->InductanceGYHD)*100: \
        (float)(psInductance->InductanceGYHD-psInductance->InductanceGYHA)/(float)(psInductance->InductanceGYHA+psInductance->InductanceGYHD)*100;
	//dir3ΪBE��Ⱥ�		
 psInductance->dir3 = (psInductance->InductanceGYHB >= psInductance->InductanceGYHE) ? \
    (float)(psInductance->InductanceGYHB-psInductance->InductanceGYHE)/ \
      (float)(psInductance->InductanceGYHB+psInductance->InductanceGYHE)*100: \
        (float)(psInductance->InductanceGYHE-psInductance->InductanceGYHB)/(float)(psInductance->InductanceGYHB+psInductance->InductanceGYHE)*100;			 

                          if(psInductance->flag)
                          {
                            psInductance->dir=-psInductance->dir;
                            psInductance->dir2=-psInductance->dir2;
                            psInductance->dir5=-psInductance->dir5;
                          }

                          psInductance->flag = psInductance->InductanceGYHB >= psInductance->InductanceGYHD ? 0 : 1;
   psInductance->dir1 = (psInductance->InductanceGYHB >=psInductance->InductanceGYHD ? \
     (float)(psInductance->InductanceGYHB -psInductance->InductanceGYHD)/ \
        (float)(psInductance->InductanceGYHB +psInductance->InductanceGYHD)*100: \
          (float)(psInductance->InductanceGYHD-psInductance->InductanceGYHB )/(float)(psInductance->InductanceGYHB +psInductance->InductanceGYHD)*100);
                          psInductance->dir = -psInductance->dir;
                          if(psInductance->flag)
                          {
                              psInductance->dir1 = -1*psInductance->dir1;
                          }
                          psInductance->dir1 = -1*psInductance->dir1;//-3.1
													psInductance->dir5 = -1*psInductance->dir5;//-3.1
													psInductance->dir2 = -1*psInductance->dir2;//-3.1
													psInductance->dir3 = -1*psInductance->dir3;//-3.1
                          if(ROUND_GO_FLAG==1)
                          {
                              if(ROUND_NUM==0)
                                  Round_Processing(ROUND1_DIR);
                              //if(ROUND_NUM==1)//�˴�ע�ͻ�����ֹ������̬���� ����
                              //    Round_Processing(ROUND2_DIR);
                              /*if(ROUND_NUM==2)
                              {
                                  if(ROUND_GO_EVERY==1)
                                  {
                                    ROUND_NUM=0;
                                    //Round1_Distance+=3100;
                                    //Round2_Distance+=3100;
                                  }
                                  else
                                      ROUND_GO_FLAG=0;
                              }*/
                          }
													Ramp_processing();
													Car_Protect();
													three_processing();
                          //Out_Parking_Prosses();
                          return (psInductance->dir);
}
/*
 *  name:   �µ���⺯��
 *  para:   NONE
 *  return: NONE
 *  writer: LYF
 *  function:�µ����������ǻ����ټ���µ�
 *  time:   2021/7/7
 */
float Ramp_Distance=0;
int Ramp_Num=0;
void Ramp_processing(void)
{//
	if(gyroscope.Balance_Angle>22 && psInductance->RampFlag==0 && psInductance->RoundFlag==0 \
		&& psInductance->ThreeFlag ==0 && psInductance->start_flag==1 && con_var.car_distance >1650 && Ramp_Num==0)
		{//����ʹ�û���2�Ļ��ֵ�һ���µ�����
			psInductance->RampFlag=1;
		}
	if(psInductance->RampFlag==1)
	{
		Ramp_Distance += ((float)s_motor.speed.now / 2.5f);
    if(Ramp_Distance > Round2_Distance)
		{
				psInductance->RampFlag=0;
				Ramp_Distance=0;
        if(Ramp_Num==0)
          Ramp_Num=1;
		}
	}
}

/*
 *  name:   ����·�ڼ�⺯��
 *  para:   NONE
 *  return: NONE
 *  writer: LYF
 *  function:���ֵ����
 *  time:   2021/5/21
 */
float three_distance=0;

void three_processing(void)
{
	if(psInductance->start_flag==1)
	{
		if(CrossRoad_Num ==1 && con_var.car_distance >CrossRoad_Distance && psInductance->ThreeFlag==0) 
		{	//�ж��Ƿ��ǲ���2
			psInductance->ThreeFlag=1;
		}
    if(CrossRoad_Num ==0 && con_var.car_distance >CrossRoad1_Distance && psInductance->ThreeFlag==0) 
		{	//�ж��Ƿ��ǲ���1
			psInductance->ThreeFlag=1;
		}
		if(psInductance->ThreeFlag==1 && (psInductance->InductanceAveNowA+psInductance->InductanceAveNowB+psInductance->InductanceAveNowC\
    +psInductance->InductanceAveNowD+psInductance->InductanceAveNowE)<5300)
		{//��������
				psInductance->ThreeFlag=2;
		}
		if(psInductance->ThreeFlag==2 && CrossRoad_Num ==1)//�ڶ���������ͣ��
		{//�������β��� ��ͣ��
			three_distance += ((float)s_motor.speed.now / 2.5f);
			if(three_distance>CrossRoad_STOP_DISTANCE)
			{
        if((psInductance->InductanceAveNowA+psInductance->InductanceAveNowB+psInductance->InductanceAveNowC\
          +psInductance->InductanceAveNowD+psInductance->InductanceAveNowE)>CrossRoad_Threshold)//���ڳ�����ֵ��ֹ��û������˫����
          {
            Ramp_Num=0;
            ROUND_NUM=0;
            coross_num=0;
            con_var.car_distance=0; //�����������������ֱ���
				    three_distance=0;
		  	    psInductance->ThreeFlag=0;
          }
			}
		}

    if((psInductance->ThreeFlag==2 ||psInductance->ThreeFlag==3)  && CrossRoad_Num ==0)//��һ������ͣ��
		{//��1���� ͣ������ ����������
			//three_distance += ((float)s_motor.speed.now /2.5f);
        psInductance->ThreeFlag=3;
        if(uart_flag == 0)
        {
          psInductance->ThreeFlag=2;
          if((psInductance->InductanceAveNowA+psInductance->InductanceAveNowB+psInductance->InductanceAveNowC\
            +psInductance->InductanceAveNowD+psInductance->InductanceAveNowE)>CrossRoad_Threshold)//���ڳ�����ֵ��ֹ��û������˫����
            {
              con_var.car_distance=0; //�����������������ֱ���
              three_distance=0;
              coross_num=0;
              CrossRoad_Num=1;
              psInductance->ThreeFlag=0;
            }
        }
		}
	}
}
/*
 *  name:   ���⴦������
 *  para:   NONE
 *  return: NONE
 *  writer: LYF
 *  function:
 *  time:   2021/7/23
 */
float Integal_angle=0;
void Out_Parking_Prosses(void)
{//׼������
  if(psInductance->Out_Park_Flag==0 && psInductance->start_flag==1)
  {
    psInductance->Out_Park_Flag=1;
  }
  //��������
  if(psInductance->Out_Park_Flag==1)
  {
    if(Park_dir==1)
    {
      Out_Park_Navdir=1;
      if(gyroscope.Gyro_Turn>0)
        Integal_angle+=((float)gyroscope.Gyro_Turn/40.0f);
    }
    else
    {
      Out_Park_Navdir=2;
      if(gyroscope.Gyro_Turn<0)
        Integal_angle-=((float)gyroscope.Gyro_Turn/40.0f);
    }
    //����ɹ�
    if(Integal_angle>Park_Integal_angle)
    {
      psInductance->Out_Park_Flag=2;
    }
  }
}
/*
 *  name:   ��⴦������
 *  para:   NONE
 *  return: NONE
 *  writer: LYF
 *  function:
 *  time:   2021/7/23
 */
float stop_dis = 0;
void In_Parking_Prosses(void)
{
  if(con_var.car_distance>Park_Distance && psInductance->In_Park_Flag==0 && psInductance->start_flag==1 && psInductance->ThreeFlag==0)
  {
    psInductance->In_Park_Flag=1;
  }
  //�������
  if(psInductance->In_Park_Flag==1)
  {
    if(Park_dir==1)
      In_Park_Navdir=1;
    else
      In_Park_Navdir=2;
    //���ɹ�
    if((psInductance->InductanceAveNowA \
		  +psInductance->InductanceAveNowB\
	  	+psInductance->InductanceAveNowC\
	  	+psInductance->InductanceAveNowD\
	  	+psInductance->InductanceAveNowE ) <200)
    {
      psInductance->In_Park_Flag=2;
    }
   }
  if( psInductance->In_Park_Flag==2)
  {
    stop_dis +=  ((float)s_motor.speed.now / 2.5f);
    if(stop_dis < 260){}
    else
    {
      stop_dis=0;
      psInductance->In_Park_Flag=3;
    }
  }
   if(psInductance->In_Park_Flag==3)
   {
      if(s_motor.speed.now<10)
      {
        psInductance->Out_Flag=1;
      }
   }

}

/*
 *  name:   ������⺯��
 *  para:   NONE
 *  return: NONE
 *  writer: LYF
 *  function:
 *  time:   2021/7/6
 */
float round1_angle=0;
float round2_angle=0;
float dis=0;
void Round_Processing(float ROUND_DIR)
{
    int Pre_dir;
    int Inside_dir;
    int Out_dir;
    if(ROUND_DIR==1)//�һ�
    {
      Pre_dir=1;
      Inside_dir=4;
      Out_dir=1;
    }
    else//��
    {
      Pre_dir=2;
      Inside_dir=3;
      Out_dir=4;
    }
    //�쵽�����ˣ��е��߷�ֹ������������ ��Ϊflag1
    if(((con_var.car_distance>Round1_Distance && ROUND_NUM==0 && CrossRoad_Num==1) ) \
     && psInductance->RoundFlag == 0 && psInductance->RampFlag==0)
    {
      psInductance->RoundFlag = 1;     
      Round_Navdir = Pre_dir;
    }
    //��������⵽�뻷�� �жԲ൥��Ѳ�� ��Ϊflag2
		if((psInductance->InductanceAveNowA \
		  +psInductance->InductanceAveNowB\
	  	+psInductance->InductanceAveNowC\
	  	+psInductance->InductanceAveNowD\
	  	+psInductance->InductanceAveNowE ) > 14000\
      && psInductance->RoundFlag==1 )
     {
        psInductance->RoundFlag = 2;
        Round_Navdir = Inside_dir;
     }
    //�뻷�ȴ������� ��Ϊflag3
    if(psInductance->RoundFlag==2)
    {
        dis += ((float)s_motor.speed.now / 2.5f);
        if(dis < Round_Wait)//�Ⱥ����
        {//�ȴ�����
            Round_Navdir = Inside_dir;
        }
        else
        {
          dis=0;
          psInductance->RoundFlag=3;
        }												
    }
    if(psInductance->RoundFlag==2 || psInductance->RoundFlag==3)
    {
      if(ROUND_DIR==1)
      {
        if(gyroscope.Gyro_Turn<0)
          round1_angle-=((float)gyroscope.Gyro_Turn/40.0f);
      }
      else
      {
        if(gyroscope.Gyro_Turn>0)
          round1_angle+=((float)gyroscope.Gyro_Turn/40.0f);
      }
    }
    //������
    if(psInductance->RoundFlag == 3 && (psInductance->InductanceAveNowB\
	  	+psInductance->InductanceAveNowC\
	  	+psInductance->InductanceAveNowD > Round_Threshold || round1_angle>17000))
    {
      round1_angle=0;
      psInductance->RoundFlag = 4;
    }
     //�����ɹ���ȴ�е��� flag��0
    if(psInductance->RoundFlag == 4)
    {		
				dis += ((float)s_motor.speed.now / 2.5f);
        if(dis< ROUNDCOLDCOUNT)
        {
          Round_Navdir=Out_dir;
        }
        else
        { 
            dis=0;
            ROUND_NUM++;
            psInductance->RoundFlag = 0;
        }
    }
}

 /*
 *  name:   ��������
 *  para:   NONE
 *  return: NONE
 *  writer: LYF
 *  function:���ֵ����
 *  time:   2021/7/6
 */
void Car_Protect(void)
{
	if((psInductance->InductanceAveNowA\
		+psInductance->InductanceAveNowB\
		+psInductance->InductanceAveNowC\
		+psInductance->InductanceAveNowD\
			+psInductance->InductanceAveNowE)\
		< 200 && psInductance->start_flag==1 && psInductance->RampFlag==0 && psInductance->Out_Park_Flag==2 && psInductance->In_Park_Flag==0)
	{
		psInductance->Out_Flag=1;
	}
}

 /*
 *  name:   ����Ԫ��ȫ�̻���(����)
 *  para:   NONE
 *  return: NONE
 *  writer: LYF
 *  function:ȫ�̻��ּ�¼׼����������ĵ�
 *  time:   2021/7/6
 */
void Integral_All_Road(void)
{
  if(psInductance->InductanceAveNowA\
		+psInductance->InductanceAveNowB\
		+psInductance->InductanceAveNowC\
		+psInductance->InductanceAveNowD\
			+psInductance->InductanceAveNowE\
		> 7000 && psInductance->start_flag==1 &&con_var.car_distance >100)
	{
		Road_Integrals.ALL_FLAG=2;//�Ӳ��������˿�ʼ������ֵ
		
	}
	//��⻷��1
	if(Road_Integrals.Test_Mode==1 && Road_Integrals.ALL_FLAG==2 && psInductance->RoundFlag !=0 && ROUND_NUM==0 && Road_Integrals.Round1_finish==0)
	{
		Road_Integrals.Round1_Distance=Road_Integrals.All_Distance;
		Road_Integrals.Round1_finish=1;
	}
	//��⻷��2
	if(Road_Integrals.Test_Mode==1 && Road_Integrals.ALL_FLAG==2 && psInductance->RoundFlag !=0 && ROUND_NUM==1 && Road_Integrals.Round2_finish==0)
	{
		Road_Integrals.Round2_Distance=Road_Integrals.All_Distance;
		Road_Integrals.Round2_finish=1;
	}
	//����µ�
	if(Road_Integrals.Test_Mode==1 && Road_Integrals.Test_Mode==1 && Road_Integrals.ALL_FLAG==2 && psInductance->RampFlag!=0 && Road_Integrals.Ramp_finish==0)
	{
		Road_Integrals.Ramp_Distance=Road_Integrals.All_Distance;
		Road_Integrals.Ramp_finish=1;
	}
	//��⽵�ٵ�1
	if(Road_Integrals.Test_Mode==1 && Road_Integrals.ALL_FLAG==2 && !KEY_Read(BKEY1) && Road_Integrals.Dowm_Point1_finish==0)
  {
		Road_Integrals.Dowm_Point1_finish=1;
		Road_Integrals.Dowm_Dista1=Road_Integrals.All_Distance;
		oled_p6x8str(0,0,"Point1_Get!");
  }
	//��⽵�ٵ�2
	if(Road_Integrals.Test_Mode==1 && Road_Integrals.ALL_FLAG==2 && !KEY_Read(BKEY2) && Road_Integrals.Dowm_Point2_finish==0)
  {
		Road_Integrals.Dowm_Point2_finish=1;
		Road_Integrals.Dowm_Dista2=Road_Integrals.All_Distance;
		oled_p6x8str(0,1,"Point2_Get!");
  }
	//��⽵�ٵ�3
	if(Road_Integrals.Test_Mode==1 && Road_Integrals.ALL_FLAG==2 && !KEY_Read(BKEY3) && Road_Integrals.Dowm_Point3_finish==0)
  {
		Road_Integrals.Dowm_Point3_finish=1;
		Road_Integrals.Dowm_Dista3=Road_Integrals.All_Distance;
		oled_p6x8str(0,2,"Point3_Get!");
  }
  //���Сs
	if(Road_Integrals.Test_Mode==1 && Road_Integrals.ALL_FLAG==2 && !KEY_Read(BKEY4) && Road_Integrals.ssss_Point_finish==0)
  {
		Road_Integrals.ssss_Point_finish=1;
		Road_Integrals.Ssss_Distan=Road_Integrals.All_Distance;
		oled_p6x8str(0,3,"SSSS_Get!");
  }
	if(psInductance->InductanceAveNowA\
		+psInductance->InductanceAveNowB\
		+psInductance->InductanceAveNowC\
		+psInductance->InductanceAveNowD\
			+psInductance->InductanceAveNowE\
		< 4000 && Road_Integrals.ALL_FLAG==2 && psInductance->RoundFlag==0  && psInductance->RampFlag==0 && con_var.car_distance>CrossRoad_Distance)
	{
		Road_Integrals.ALL_FLAG=3;//�ֽ�������,ֹͣ����
    if(Road_Integrals.Test_Mode==1 && 0)
    {
      oled_p6x8str(0,0,"All_Dis:");
		  oled_printf_float(49,0,Road_Integrals.All_Distance,5,1);
		  oled_p6x8str(0,1,"Round1_Dis:");
		  oled_printf_float(67,1,Road_Integrals.Round1_Distance,5,1);
		  oled_p6x8str(0,2,"Round2_Dis:");
		  oled_printf_float(67,2,Road_Integrals.Round2_Distance,5,1);
		  oled_p6x8str(0,3,"Ramp_Dis:");
		  oled_printf_float(55,3,Road_Integrals.Ramp_Distance,5,1);
		  oled_p6x8str(0,4,"Down_Dis1:");
		  oled_printf_float(61,4,Road_Integrals.Dowm_Dista1,5,1);
		  oled_p6x8str(0,5,"Down_Dis2:");
		  oled_printf_float(61,5,Road_Integrals.Dowm_Dista2,5,1);
		  oled_p6x8str(0,6,"Down_Dis3:");
		  oled_printf_float(61,6,Road_Integrals.Dowm_Dista3,5,1);
		  oled_p6x8str(0,7,"SSSS_Dist:");
		  oled_printf_float(61,7,Road_Integrals.Ssss_Distan,5,1);
      //д��FLASH����
      Integal_data_buffer[2]=Road_Integrals.All_Distance;
      Integal_data_buffer[3]=Road_Integrals.Round1_Distance;
      Integal_data_buffer[4]=Road_Integrals.Round2_Distance;
      Integal_data_buffer[5]=Road_Integrals.Ramp_Distance;
      Integal_data_buffer[6]=Road_Integrals.Dowm_Dista1;
      Integal_data_buffer[7]=Road_Integrals.Dowm_Dista2;
      Integal_data_buffer[8]=Road_Integrals.Dowm_Dista3;
      Integal_data_buffer[9]=Road_Integrals.Ssss_Distan;
      flash_erase_page(FLASH_SECTION_127, FLASH_PAGE_0);
      flash_page_program(FLASH_SECTION_127, FLASH_PAGE_0, Integal_data_buffer, DATA_SIZE);
    }
	}
}
//////////////////////////////////////////////////////////////////////
 /*
 *  name:   ��һ������
 *  para:   NONE
 *  return: NONE
 *  writer: LYF           
 *  function:���ֵ����  
 *  time:   2021/7/6      ��1 ��2
 */
float Turn_angles=0;
float temp_dis=0;
float temp_angle=0;
int flags=0;
void First_Task(int dir)
{
  int i=0;
  if(psInductance->First_Task_flag==0 && con_var.car_distance>2650)//2650Ϊ��һ��·��
	{
    psInductance->First_Task_flag=1;//����1800����һ��ʮ����� ����ͣ��
    temp_dis=con_var.car_distance;
    Stop_flag=1;
	}
  if(psInductance->First_Task_flag==1 && (con_var.car_distance-temp_dis)>0)//����һ��ͣ��
  {
    psInductance->First_Task_flag=2;
    Stop_flag=1;
  }
  if(psInductance->First_Task_flag==2 && s_motor.speed.now<5)//ͣ��
  { Stop_flag=0;
    if(dir==1)//��
    {
      Left_TurnFlag=1;//�ٶ��������� ����ת��90��
    }
    else if(dir==2)//��
    {
      Right_TurnFlag=1;//�ٶ��������� ����ת��90��
    }
    psInductance->First_Task_flag=3;
  }
  if(psInductance->First_Task_flag==3)
  {
    if(dir==1)
    {
      if(gyroscope.Gyro_Turn>0)
        Turn_angles+=((float)gyroscope.Gyro_Turn/20.0f);
      if(Turn_angles>6000)
      {
        Turn_angles=0;
        psInductance->First_Task_flag=4;
        temp_dis=con_var.car_distance;
        Left_TurnFlag=0;;
      }
    }
    else//��ת
    {
      if(gyroscope.Gyro_Turn<0)
        Turn_angles-=((float)gyroscope.Gyro_Turn/20.0f);
      if(Turn_angles>6000)
      {
        Turn_angles=0;
        psInductance->First_Task_flag=4;
        temp_dis=con_var.car_distance;
        Right_TurnFlag=0;
      }
    }
  }
  if(psInductance->First_Task_flag==4 && (con_var.car_distance-temp_dis)>1500)
  {
      temp_dis=0;
      psInductance->First_Task_flag=5;//����ȡҩ
      Stop_flag=1;
      flags=0;
      gpio_set(RGB2,0);//��
  }
  if(psInductance->First_Task_flag==5 &&  gpio_get(test))
  {
    gpio_set(RGB2,1);
    psInductance->First_Task_flag=6;
    
  }
  if(psInductance->First_Task_flag==6)
  {
    flags++;
    if(flags>100)
    {
      Right_TurnFlag=1;//�ٶ��������� ����ת��90��
      Stop_flag=0;//ȡ��ҩƷ�Ⱥ򷢳�
      if(gyroscope.Gyro_Turn<0)
      Turn_angles-=((float)gyroscope.Gyro_Turn/20.0f);
      if(Turn_angles>17000 )//&& abs(image_Error)<50)
      {
        flags=0;
        Right_TurnFlag=0;
        Turn_angles=0;
        psInductance->First_Task_flag=7;
        temp_dis=con_var.car_distance;
        Stop_flag=0;
        psInductance->corss_flag=0;
      }
    }
 
  }
  if(psInductance->First_Task_flag==7 &&  (con_var.car_distance-temp_dis)>1500)
  {
    temp_dis=0;
    psInductance->First_Task_flag=8;
    Stop_flag=1;
  }
  if(psInductance->First_Task_flag==8 &&  s_motor.speed.now<5)
  {
    temp_dis=0;
    psInductance->First_Task_flag=9;
    Stop_flag=0;
    if(dir==1)
    {
      Right_TurnFlag=1;
    }
    else
    {
      Left_TurnFlag=1;
    }
  }
  if(psInductance->First_Task_flag==9)
  {
    if(dir==1)
    {
      if(gyroscope.Gyro_Turn<0)
      Turn_angles-=((float)gyroscope.Gyro_Turn/20.0f);
      if(Turn_angles>5800)
      {
        Right_TurnFlag=0;
        Turn_angles=0;
        psInductance->First_Task_flag=10;
        temp_dis=con_var.car_distance;
      }
    }
    else
    {
      if(gyroscope.Gyro_Turn>0)
      Turn_angles+=((float)gyroscope.Gyro_Turn/20.0f);
      if(Turn_angles>5800)
      {
        Left_TurnFlag=0;
        Turn_angles=0;
        psInductance->First_Task_flag=10;
        temp_dis=con_var.car_distance;
      }
    }

  }
  if(psInductance->First_Task_flag==10 && (con_var.car_distance-temp_dis)>2400-1200)//2650
  {
    go_flag=1;
    if((con_var.car_distance-temp_dis)>2400)
      Stop_flag=1,gpio_set(RGB3,0);
  }
}

//////////////////////////////////////////////////////////////////////
 /*
 *  name:   ��2������
 *  para:   NONE
 *  return: NONE
 *  writer: LYF           
 *  function:���ֵ����  
 *  time:   2021/7/6      ��1 ��2
 */
void Second_Task(int dir)
{
  int i=0;
  if(psInductance->Second_Task_flag==0 )//2650Ϊ��һ��·��
	{
    psInductance->Second_Task_flag=1;//����1800����һ��ʮ����� ����ͣ��
    temp_dis=con_var.car_distance;
	}
  if(psInductance->Second_Task_flag==1 && (con_var.car_distance-temp_dis)>800)//����һ��ͣ��
  {
    temp_dis=0;
    psInductance->Second_Task_flag=2;
    Stop_flag=1;
  }
  if(psInductance->Second_Task_flag==2 && s_motor.speed.now<5)//ͣ��
  { Stop_flag=0;
    if(dir==1)//��
    {
      Left_TurnFlag=1;//�ٶ��������� ����ת��90��
    }
    else if(dir==2)//��
    {
      Right_TurnFlag=1;//�ٶ��������� ����ת��90��
    }
    psInductance->Second_Task_flag=3;
  }
  if(psInductance->Second_Task_flag==3)
  {
    if(dir==1)
    {
      if(gyroscope.Gyro_Turn>0)
        Turn_angles+=((float)gyroscope.Gyro_Turn/20.0f);
      if(Turn_angles>6000)
      {
        Turn_angles=0;
        psInductance->Second_Task_flag=4;
        temp_dis=con_var.car_distance;
        Left_TurnFlag=0;;
      }
    }
    else//��ת
    {
      if(gyroscope.Gyro_Turn<0)
        Turn_angles-=((float)gyroscope.Gyro_Turn/20.0f);
      if(Turn_angles>6000)
      {
        Turn_angles=0;
        psInductance->Second_Task_flag=4;
        temp_dis=con_var.car_distance;
        Right_TurnFlag=0;
      }
    }
  }
  if(psInductance->Second_Task_flag==4 && (con_var.car_distance-temp_dis)>1500)
  {
      temp_dis=0;
      psInductance->Second_Task_flag=5;//����ȡҩ
      //1������
      if(cross2_left==mission_number)
      {
        uart_putchar(UART_1,50);
      }
      else
      {
        uart_putchar(UART_1,49);//1-9
      }
      Stop_flag=1;
      gpio_set(RGB2,0);
  }
  if(psInductance->Second_Task_flag==5 &&  gpio_get(test))
  {
    gpio_set(RGB2,1);
    uart_putchar(UART_1,55);
    psInductance->Second_Task_flag=6;
  }
  if(psInductance->Second_Task_flag==6)
  {
    flags++;
    if(flags>100)
    {
      Right_TurnFlag=1;//�ٶ��������� ����ת��90��
       if(gyroscope.Gyro_Turn<0)
      Turn_angles-=((float)gyroscope.Gyro_Turn/20.0f);
      if(Turn_angles>17000 )//&& abs(image_Error)<50)
      {
        Right_TurnFlag=0;
        Turn_angles=0;
        psInductance->Second_Task_flag=7;
        temp_dis=con_var.car_distance;
        Stop_flag=0;
        flags=0;
        psInductance->corss_flag=0;
      }
    }

  }
  if(psInductance->Second_Task_flag==7 &&  (con_var.car_distance-temp_dis)>1500)
  {
    temp_dis=0;
    psInductance->Second_Task_flag=8;
    Stop_flag=1;
  }
  if(psInductance->Second_Task_flag==8 &&  s_motor.speed.now<5)
  {
    temp_dis=0;
    psInductance->Second_Task_flag=9;
    Stop_flag=0;
    //1������

    if(dir==1)
    {
      Right_TurnFlag=1;
    }
    else
    {
      Left_TurnFlag=1;
    }
  }
  if(psInductance->Second_Task_flag==9)
  {
    if(dir==1)
    {
      if(gyroscope.Gyro_Turn<0)
      Turn_angles-=((float)gyroscope.Gyro_Turn/20.0f);
      if(Turn_angles>7000)
      {
        Right_TurnFlag=0;
        Turn_angles=0;
        psInductance->Second_Task_flag=10;
        temp_dis=con_var.car_distance;
        uart_putchar(UART_1,23);//�ٷ����� ���2��������ݸ��´���9 ����
      }
    }
    else
    {
      if(gyroscope.Gyro_Turn>0)
      Turn_angles+=((float)gyroscope.Gyro_Turn/20.0f);
      if(Turn_angles>7000)
      {
        Left_TurnFlag=0;
        Turn_angles=0;
        psInductance->Second_Task_flag=10;
        temp_dis=con_var.car_distance;
        uart_putchar(UART_1,23);//�ٷ����� ���2��������ݸ��´���9 ����
      }
    }

  }
  if(psInductance->Second_Task_flag==10 && (con_var.car_distance-temp_dis)>5600-1200)//2650
  {
    go_flag=1;
    if((con_var.car_distance-temp_dis)>5600)
    gpio_set(RGB3,0),Stop_flag=1;
  }
}
///////////////////////////////////////////////////////////////////////////////////////////////////

void Third_Task(int dir,int dir2)
{
  int i=0;

  if(psInductance->Third__turn2Flag==0)
  {
      temp_dis=con_var.car_distance;
      Stop_flag=0;
      go_flag=1;
      psInductance->Third__turn2Flag=1;
  }
  if(psInductance->Third__turn2Flag==1 && (con_var.car_distance-temp_dis)>940)
  {
      go_flag=0;
      temp_dis=0;
      Stop_flag=1;
      psInductance->Third__turn2Flag=2;
  }
  if(psInductance->Third__turn2Flag==2 && s_motor.speed.now<5)
  {
    Stop_flag=0;
    temp_dis=0;
    if(dir2==1)//��
    {
      Left_TurnFlag=1;//�ٶ��������� ����ת��90��
    }
    else if(dir2==2)//��
    {
      Right_TurnFlag=1;//�ٶ��������� ����ת��90��
    }
    psInductance->Third__turn2Flag=6;
  }
  if(psInductance->Third__turn2Flag==6)
  {
    if(dir2==1)
    {
      if(gyroscope.Gyro_Turn>0)
      Turn_angles+=((float)gyroscope.Gyro_Turn/20.0f);
      if(Turn_angles>9000)
      {
        Left_TurnFlag=0;
        Turn_angles=0;
        psInductance->Third__turn2Flag=7;
        temp_dis=con_var.car_distance;
      }
    }
    else
    {
      if(gyroscope.Gyro_Turn<0)
      Turn_angles-=((float)gyroscope.Gyro_Turn/20.0f);
      if(Turn_angles>9000)
      {
        Right_TurnFlag=0;
        Turn_angles=0;
        psInductance->Third__turn2Flag=7;
        temp_dis=con_var.car_distance;
      }
    }
  }
  if(psInductance->Third__turn2Flag==7 &&  (con_var.car_distance-temp_dis)>1500)
  {
    Stop_flag=1;
    psInductance->Third__turn2Flag=8;
    flags=0;
    gpio_set(RGB2,0);
  }
  if(psInductance->Third__turn2Flag==8 &&  gpio_get(test))
  {
    gpio_set(RGB2,1);
    
    psInductance->Third__turn2Flag=9;
    
  }
  if(psInductance->Third__turn2Flag==9)
  {
      flags++;
      if(flags>100)
      {
       
      Stop_flag=0;
      Right_TurnFlag=1;
      if(gyroscope.Gyro_Turn<0)
      Turn_angles-=((float)gyroscope.Gyro_Turn/20.0f);
      if(Turn_angles>17000 )//&& abs(image_Error)<50)
      {
        flags=0; 
        Right_TurnFlag=0;
        Turn_angles=0;
        psInductance->Third__turn2Flag=10;
        temp_dis=con_var.car_distance;
        Stop_flag=0;
      }
      }

  }
  if(psInductance->Third__turn2Flag==10 &&  (con_var.car_distance-temp_dis)>1500)
  {
    temp_dis=0;
    psInductance->Third__turn2Flag=11;
     Stop_flag=1;
  }
  if(psInductance->Third__turn2Flag==11 &&  s_motor.speed.now<5)
  {
    psInductance->Third__turn2Flag=12;
    Stop_flag=0;
    if(dir2==1)
    {
      Right_TurnFlag=1;
    }
    else
    {
      Left_TurnFlag=1;
    }
  }
  if(psInductance->Third__turn2Flag==12)
  {
    if(dir2==1)
    {
      if(gyroscope.Gyro_Turn<0)
      Turn_angles-=((float)gyroscope.Gyro_Turn/20.0f);
      if(Turn_angles>7000)
      {
        Right_TurnFlag=0;
        Turn_angles=0;
        psInductance->Third__turn2Flag=13;
        temp_dis=con_var.car_distance;
      }
    }
    else
    {
      if(gyroscope.Gyro_Turn>0)
      Turn_angles+=((float)gyroscope.Gyro_Turn/20.0f);
      if(Turn_angles>7000)
      {
        Left_TurnFlag=0;
        Turn_angles=0;
        psInductance->Third__turn2Flag=13;
        temp_dis=con_var.car_distance;
      }
    }
  }
  if(psInductance->Third__turn2Flag==13 &&  (con_var.car_distance-temp_dis)>3200)
  {
    temp_dis=0;
    psInductance->Third__turn2Flag=14;
    Stop_flag=1;
  }
  if(psInductance->Third__turn2Flag==14 &&  s_motor.speed.now<5)
  {
    temp_dis=0;
    psInductance->Third__turn2Flag=15;
    Stop_flag=0;
    if(dir==1)
    {
      Right_TurnFlag=1;
    }
    else
    {
      Left_TurnFlag=1;
    }
  }
  if(psInductance->Third__turn2Flag==15)//3�ſ�ת��FLAG
  {
    if(dir==1)
    {
      if(gyroscope.Gyro_Turn<0)
      Turn_angles-=((float)gyroscope.Gyro_Turn/20.0f);
      if(Turn_angles>7000)
      {
        Right_TurnFlag=0;
        Turn_angles=0;
        psInductance->Third__turn2Flag=16;
        temp_dis=con_var.car_distance;
      }
    }
    else
    {
      if(gyroscope.Gyro_Turn>0)
      Turn_angles+=((float)gyroscope.Gyro_Turn/20.0f);
      if(Turn_angles>7000)
      {
        Left_TurnFlag=0;
        Turn_angles=0;
        psInductance->Third__turn2Flag=16;
        temp_dis=con_var.car_distance;
      }
    }

  }
  if(psInductance->Third__turn2Flag==16 && (con_var.car_distance-temp_dis)>8900-1200)//2650
  {
    go_flag=1;
    if((con_var.car_distance-temp_dis)>8900)
      Stop_flag=1,gpio_set(RGB3,0);
  }
}



void Second_cross_Task(void)
{
  int i=0;
  if(psInductance->First_Task_flag==0 && con_var.car_distance>4850)//4500Ϊ��һ��·��
	{
    psInductance->First_Task_flag=1;//����1800����һ��ʮ����� ����ͣ��
    temp_dis=con_var.car_distance;
    Stop_flag=1;
	}
  if(psInductance->First_Task_flag==1 && s_motor.speed.now<5)//��⵽���Ѿ���ȫͣ��
  {
    Left_TurnFlag=1;
    psInductance->First_Task_flag=2;
    Stop_flag=0;
  }
  if(psInductance->First_Task_flag==2)
  {
      if(gyroscope.Gyro_Turn>0)
        Turn_angles+=((float)gyroscope.Gyro_Turn/20.0f);
      if(Turn_angles>1000)
      {
        Turn_angles=0;
        psInductance->First_Task_flag=3;
        Left_TurnFlag=0;
        Stop_flag=1;
        flags=0;
      }
  }
  if(psInductance->First_Task_flag==3)
  {
    flags++;
    cross2_left=NUM_GET;
    if(flags>100)
    {
      flags=0;
      psInductance->First_Task_flag=4;
      Right_TurnFlag=1;
    }
  }
  if(psInductance->First_Task_flag==4)
  {
      if(gyroscope.Gyro_Turn<0)
      Turn_angles-=((float)gyroscope.Gyro_Turn/20.0f);
      if(Turn_angles>2000)
      {
        Turn_angles=0;
        psInductance->First_Task_flag=5;
        Right_TurnFlag=0;;
        Stop_flag=1;
        flags=0;
      }
  }
  if(psInductance->First_Task_flag==5)
  {
    flags++;
    cross2_right=NUM_GET;
    if(flags>100)
    {
      flags=0;
      psInductance->First_Task_flag=6;
      Left_TurnFlag=1;
    }
  }
  if(psInductance->First_Task_flag==6)
  {
      if(gyroscope.Gyro_Turn>0)
      Turn_angles+=((float)gyroscope.Gyro_Turn/20.0f);
      if(Turn_angles>500)
      {
        Turn_angles=0;
        psInductance->First_Task_flag=7;
        Left_TurnFlag=0;
        Stop_flag=1;
      }
  }
  if(psInductance->First_Task_flag==7 &&  s_motor.speed.now<5)
  {

      psInductance->First_Task_flag=8;
      if(mission_number==cross2_left)
        psInductance->Cross1_Finish_flag=1;//��
      else if(mission_number==cross2_right)  
        psInductance->Cross1_Finish_flag=2;//��
      else
       psInductance->Cross1_Finish_flag=3;//������ǰ
      Stop_flag=0;
  }
}


int cross3_left1=0;
int cross3_left2=0;
int cross3_right1=0;
int cross3_right2=0;
void Third_cross_Task(void)
{
  int i=0;
  if(psInductance->Third_Task_flag==0 )//4500Ϊ��һ��·��
	{
    psInductance->Third_Task_flag=1;
    temp_dis=con_var.car_distance;
    Stop_flag=0;
	}
  if(psInductance->Third_Task_flag==1 && (con_var.car_distance-temp_dis)>3270)//��⵽���Ѿ���ȫͣ��
  {
    Stop_flag=1;
    psInductance->Third_Task_flag=2;
  }
  if(psInductance->Third_Task_flag==2 && s_motor.speed.now<5)
  {
    Left_TurnFlag=1;
    psInductance->Third_Task_flag=3;
  }
  if(psInductance->Third_Task_flag==3)
  {
      if(gyroscope.Gyro_Turn>0)
      Turn_angles+=((float)gyroscope.Gyro_Turn/20.0f);
      if(Turn_angles>2200)//2500
      {
        Turn_angles=0;
        psInductance->Third_Task_flag=4;
        Left_TurnFlag=0;;
        Stop_flag=1;
        flags=0;
      }
  }
  if(psInductance->Third_Task_flag==4)
  {
    flags++;
    cross3_left1 = NUM_GET;
    if(flags>100)
    {
      flags=0;
      psInductance->Third_Task_flag=5;
      Right_TurnFlag=1;
    }
  }
  if(psInductance->Third_Task_flag==5)
  {
      if(gyroscope.Gyro_Turn<0)
        Turn_angles-=((float)gyroscope.Gyro_Turn/20.0f);
      if(Turn_angles>600)
      {
        Turn_angles=0;
        psInductance->Third_Task_flag=6;
        Right_TurnFlag=0;
        Stop_flag=1;
        flags=0;
      }
  }
  if(psInductance->Third_Task_flag==6)
  {
    flags++;
    if(NUM_GET!=cross3_left1)
      cross3_left2=NUM_GET;
    if(flags>100)
    {
      flags=0;
      psInductance->Third_Task_flag=7;
      Right_TurnFlag=1;
    }
  }
  if(psInductance->Third_Task_flag==7)
  {
      if(gyroscope.Gyro_Turn<0)
      Turn_angles-=((float)gyroscope.Gyro_Turn/20.0f);
      if(Turn_angles>1000)
      {
        Turn_angles=0;
        psInductance->Third_Task_flag=8;
        Right_TurnFlag=0;;
        Stop_flag=1;
        flags=0;
      }
  }
  if(psInductance->Third_Task_flag==8)
  {
    flags++;
    if(NUM_GET!=cross3_left1 && NUM_GET!=cross3_left2)
      cross3_right1=NUM_GET;
    if(flags>100)
    {
      if((mission_number!=cross3_left1) && (mission_number!=cross3_left2))
      {
        flags=0;
        psInductance->Third_Task_flag=9;
        psInductance->Cross2_Finish_flag=2;
      }
      else
      {
        flags=0;
        psInductance->Third_Task_flag=9;
        psInductance->Cross2_Finish_flag=1;
      }
      
    }
  }
}

void Third_cross_turn(int dir)
{
  int i=0;
  if(psInductance->Third__turn1Flag==0)
	{
    psInductance->Third__turn1Flag=1;//����1800����һ��ʮ����� ����ͣ��
    temp_dis=con_var.car_distance;
    Stop_flag=0;
	}
  if(psInductance->Third__turn1Flag==1 && (con_var.car_distance-temp_dis)>900)//����һ��ͣ��
  {
    psInductance->Third__turn1Flag=2;
    Stop_flag=1;
  }
  
  if(psInductance->Third__turn1Flag==2 && s_motor.speed.now<5)//ͣ��
  { 
    Stop_flag=0;
    if(dir==1)//��
    {
      Left_TurnFlag=1;//�ٶ��������� ����ת��90��
    }
    else if(dir==2)//��
    {
      Right_TurnFlag=1;//�ٶ��������� ����ת��90��
    }
    psInductance->Third__turn1Flag=3;
  }
  if(psInductance->Third__turn1Flag==3)
  {
    if(dir==1)
    {
      if(gyroscope.Gyro_Turn>0)
        Turn_angles+=((float)gyroscope.Gyro_Turn/20.0f);
      if(Turn_angles>5000)
      {
        Turn_angles=0;
        psInductance->Third__turn1Flag=4;
        temp_dis=con_var.car_distance;
        Left_TurnFlag=0;;
      }
    }
    else//��ת
    {
      if(gyroscope.Gyro_Turn<0)
        Turn_angles-=((float)gyroscope.Gyro_Turn/20.0f);
      if(Turn_angles>5000)
      {
        Turn_angles=0;
        psInductance->Third__turn1Flag=4;
        temp_dis=con_var.car_distance;
        Right_TurnFlag=0;
      }
    }
  }
  if(psInductance->Third__turn1Flag==4 && (con_var.car_distance-temp_dis)>2150)
  {
      temp_dis=0;
      psInductance->Third__turn1Flag=5;
      Stop_flag=1;
  }
  if(psInductance->Third__turn1Flag==5 && s_motor.speed.now<5)
  {
    Left_TurnFlag=1;
    psInductance->Third__turn1Flag=6;
  }
  if(psInductance->Third__turn1Flag==6)
  {
      if(gyroscope.Gyro_Turn>0)
      Turn_angles+=((float)gyroscope.Gyro_Turn/20.0f);
      if(Turn_angles>900)
      {
        Turn_angles=0;
        psInductance->Third__turn1Flag=7;
        Left_TurnFlag=0;;
        Stop_flag=1;
        flags=0;
      }
  }
  if(psInductance->Third__turn1Flag==7)
  {
    flags++;
    cross3_left1 = NUM_GET;
    if(flags>100)
    {
      flags=0;
      psInductance->Third__turn1Flag=8;
      Right_TurnFlag=1;
    }
  }
  if(psInductance->Third__turn1Flag==8)
  {
      if(gyroscope.Gyro_Turn<0)
      Turn_angles-=((float)gyroscope.Gyro_Turn/20.0f);
      if(Turn_angles>900)
      {
        Turn_angles=0;
        psInductance->Third__turn1Flag=9;
        Right_TurnFlag=0;;
        Stop_flag=1;
        flags=0;
        if(dir==1)
        {
          if(mission_number==cross3_left1)
            psInductance->Cross3_Finish_flag=1;
          else
            psInductance->Cross3_Finish_flag=2;
        }
        else
        {
          if(mission_number==cross3_left1)
            psInductance->Cross3_Finish_flag=3;
          else
            psInductance->Cross3_Finish_flag=4;
        }
      }
  }
}



int  findMax(int a[9])
{
 int i,j,k;
 j=a[0];
 for(i=0;i<9;i++)
 {
  if (a[i]>j)
  {
   j=a[i];
   k=i;
  }
 }
 return k+1;
}
int mission_number=0;
void Get_Misson_nums(void)
{
  systick_delay_ms(250);
  mission_number=NUM_GET;
  systick_delay_ms(250);
  mission_number=NUM_GET;
  systick_delay_ms(250);
  mission_number=NUM_GET;
  systick_delay_ms(250);
  mission_number=NUM_GET;
  systick_delay_ms(250);
  mission_number=NUM_GET;
  systick_delay_ms(250);
  mission_number=NUM_GET;
  systick_delay_ms(250);
  mission_number=NUM_GET;
  systick_delay_ms(250);
  mission_number=NUM_GET;
  systick_delay_ms(250);
  mission_number=NUM_GET;
  systick_delay_ms(250);
  mission_number=NUM_GET;
  systick_delay_ms(250);
  mission_number=NUM_GET;
  systick_delay_ms(250);
  mission_number=NUM_GET;
    systick_delay_ms(250);
  mission_number=NUM_GET;
  systick_delay_ms(250);
  mission_number=NUM_GET;


}
void Mission_Control(void)
{
  if(mission_number==1)
  {
    First_Task(1);
  }
  else if(mission_number==2)
  {
    First_Task(2);
  }
  else 
  {
    if(psInductance->Cross1_Finish_flag==0)
      Second_cross_Task();
    else if(psInductance->Cross1_Finish_flag==1)
      Second_Task(1);
    else if(psInductance->Cross1_Finish_flag==2)
      Second_Task(2);
    else
//////////////////////////������һ��ʮ��·��////////////////////////
    {
      if(psInductance->Cross2_Finish_flag==0)
        Third_cross_Task();//�������
      else if(psInductance->Cross2_Finish_flag==1)//������
      {
        if(psInductance->Cross3_Finish_flag==0)
          Third_cross_turn(1);
        else if(psInductance->Cross3_Finish_flag==1)
        {
          Third_Task(1,1);
        }
        else if(psInductance->Cross3_Finish_flag==2)
        {
          Third_Task(1,2);
        }
      }
      else if(psInductance->Cross2_Finish_flag==2)//���Ҳ��
      {
        if(psInductance->Cross3_Finish_flag==0)
          Third_cross_turn(2);
        else if(psInductance->Cross3_Finish_flag==3)
        {
          Third_Task(2,1);
        }
        else if(psInductance->Cross3_Finish_flag==4)
        {
          Third_Task(2,2);
        }
      }
    }
////////////////////////////////////////////////////////////////////
  }
}