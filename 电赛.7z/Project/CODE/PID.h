/****************************************************************
 * @file            PID.h
 * @school          �ϲ����մ�ѧ��ʮ����ȫ����ѧ�����ܳ�����˫��������
 * @author          LYF/OREO
 * @version         v2.0
 * @Software        KEIL
 * @Target core     MM32F3277G
 * @date            2021-3-19
****************************************************************/
#ifndef _PID_h
#define _PID_h

#define KP 0
#define KI 1
#define KD 2
#define KT 3
#define KB 4
#define KF 5
extern float erect_speed[5];
extern float erect_ang_vel[5];
extern float erect_angle[5];
extern float erect_direct_vel[5];
extern float erect_turn[5][5];

extern float left_speed_vel[5];
extern float right_speed_vel[5];
typedef struct
{
    int   iError;                 //���
    int   LastError;              //�ϴ����
    int   PrevError;              //���ϴ����
    int   LastData;               //��һ������
    float iErrorHistory[5];       //��ʷ���
    float SumError;               //����ۻ�
} PID_INFO;

typedef struct
{
    PID_INFO speed_pid;             //�ٶ�
    PID_INFO angle_pid;             //�Ƕ�
    PID_INFO ang_vel_pid;           //���ٶ�
    PID_INFO turn_vel_pid;          //ת����ٶ�
    PID_INFO turn_pid;              //ת��
    PID_INFO Right_speed_pid;       //�ٶ�
    PID_INFO Left_speed_pid;        //�Ƕ�
} PID_ERECT;
extern int PID_PositionDynamic(PID_INFO *pid_info, float * PID_Parm, float NowPoint, float SetPoint);
extern int PID_Position(PID_INFO *pid_info, float *PID_Parm, float NowPoint, float SetPoint);
extern int PID_Increase(PID_INFO *pid_info, float *PID_Parm, int NowPoint, int SetPoint);
extern void pid_para_init(PID_INFO *pid_info);
extern PID_ERECT s_pid;
#endif