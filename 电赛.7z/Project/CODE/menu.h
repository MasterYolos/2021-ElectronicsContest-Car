#ifndef _MENU_h
#define _MENU_h
extern int Receive_Data;
extern void menu(int flag);
extern void Get_Mes(void);
#endif