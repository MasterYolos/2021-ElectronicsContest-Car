#ifndef _THREAD_h
#define _THREAD_h
extern void task_2ms(void);
extern void task_4ms(void);
extern void task_8ms(void);
extern void task_20ms(void);
extern void task_40ms(void);
typedef struct
{
    void(*task_func)(void);
    int interval_time;
    int run_timer;
    unsigned char  run_sign;
} schedule_task_t;

typedef struct
{
     float Gyro_Balance;
     float Gyro_Turn;
     float Ori_Acc_Z;
     float Ori_Acc_X;
     float Ori_Gyro_X;
     float Ori_Gyro_Y;
     float Acc_fiter_X;
     float Acc_fiter_Z;
     float Gyro_fiter_X;
     float Gyro_fiter_Y;
     float Acceleration_Z;
     float Acceleration_X;
     float Acceleration_Angle;
     float Balance_Angle;
     int target_angle_vel_y;
     int target_angle_y;
} GYRO_VAR;

typedef struct
{
    short theory_duty;
    short turn_duty;
    short turn_duty_last;
    short turn_speed_min;
    short radius;
    short reduce_speed;
    short reduce_duty;
    float car_distance;
    short left_theory_duty;
    short right_theory_duty;
} CON_VAR;
extern GYRO_VAR gyroscope;
extern CON_VAR con_var;
extern int limit_ab(int x, int a, int b);
extern void task_interrupt(void);
extern void task_process(void); 
extern int Left_TurnFlag;
extern int Right_TurnFlag;
extern int uart_flag;
extern int Stop_flag;
extern int go_flag;
extern float Target_Speed;
extern unsigned char NUM_GET;
extern unsigned char ADD1_flag;
#endif