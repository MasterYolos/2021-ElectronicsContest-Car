/****************************************************************
 * @file            lqi2c.c
 * @school          �ϲ����մ�ѧ��ʮ����ȫ����ѧ�����ܳ�����˫��������
 * @author          LYF/OREO
 * @version         v2.0
 * @Software        KEIL
 * @Target core     MM32F3277G �������ļ�
 * @date            2021-3-19
****************************************************************/
#include "lq_i2c.h"
#include "headfile.h"
void iic_delay(uint8_t us)
{
    for(int i = 0; i < 40; i++)    //40
    {
        __asm("NOP");//core bus 600M  ?????IIC?? 400K
    }
}

void IIC_Init(void)
{			
    
	 gpio_init(VL53_SCL, GPO, GPIO_HIGH, GPO_PUSH_PULL);
	  gpio_init(VL53_SDA, GPO, GPIO_HIGH, GPO_OPEN_DTAIN);
    
    IIC_SCL_H; 
    IIC_SDA_H;

}
/******************************************************************************
*?  ?:void IIC_Start(void)
*? ?:??IIC????
*?  ?:?
*???:?
*?  ?:?
*******************************************************************************/	
void IIC_Start(void)
{
	SDA_OUT;   //sda??? 
	IIC_SDA_H;	
	IIC_SCL_H;
	iic_delay(4);
 	IIC_SDA_L; //START:when CLK is high,DATA change form high to low 
	iic_delay(4);
	IIC_SCL_L; //??I2C??,????????? 
}

/******************************************************************************
*?  ?:void IIC_Stop(void)
*? ?:??IIC????
*?  ?:?
*???:?
*?  ?:?
*******************************************************************************/	  
void IIC_Stop(void)
{
	SDA_OUT; //sda???
	IIC_SCL_L;
	IIC_SDA_L; //STOP:when CLK is high DATA change form low to high
    iic_delay(4);
	IIC_SCL_H; 
    iic_delay(4);
	IIC_SDA_H; //??I2C??????
    iic_delay(4);							   	
}

/******************************************************************************
*?  ?: uint8_t IIC_WaitAck(void)
*? ?: ???????? (????:???9? SCL=0 ? SDA ?????,
?? SCL = 1? SDA????)
*?  ?:?
*???:1,??????
0,??????
*?  ?:????????
*******************************************************************************/
uint8_t IIC_WaitAck(void)
{
	uint8_t ucErrTime=0;
	SDA_IN; //SDA?????  (????????????) 
	IIC_SDA_H;iic_delay(1);	   
	IIC_SCL_H;iic_delay(1);	 
	while(IIC_SDA_READ)
	{
		ucErrTime++;
		if(ucErrTime>250)
		{
			IIC_Stop();
			return 1;
		}
	}
	IIC_SCL_L; //????0 	   
	return 0;  
} 

/******************************************************************************
*?  ?: void IIC_Ack(void)
*? ?: ??ACK?? (????????????,?????ACK??????
?????????)
*?  ?:?
*???:?
*?  ?:????????
*******************************************************************************/

void IIC_Ack(void)
{
	IIC_SCL_L;
	SDA_OUT;
	IIC_SDA_L;
	iic_delay(1);
	IIC_SCL_H;
	iic_delay(2);
	IIC_SCL_L;
}

/******************************************************************************
*?  ?: void IIC_NAck(void)
*? ?: ??NACK?? (??????????????,?????NACK????
????,??SDA,??????????)
*?  ?:?
*???:?
*?  ?:????????
*******************************************************************************/
void IIC_NAck(void)
{
	IIC_SCL_L;
	SDA_OUT;
	IIC_SDA_H;
	iic_delay(1);
	IIC_SCL_H;
	iic_delay(1);
	IIC_SCL_L;
}					 				     

/******************************************************************************
*?  ?:void IIC_SendByte(uint8_t txd)
*?  ?:IIC??????
*?  ?:data ?????
*???:?
*?  ?:??????
*******************************************************************************/		  
void IIC_SendByte(uint8_t data)
{                        
    uint8_t t;   
    SDA_OUT; 	    
    IIC_SCL_L; //??????????
    for(t=0;t<8;t++)
    {     
        if(data&0x80)
        {
            IIC_SDA_H;
        }
        else 
        {
            IIC_SDA_L;
        }
        iic_delay(1);			
        IIC_SCL_H;
        data<<=1;
        iic_delay(1);
        IIC_SCL_L;	   
    }
    iic_delay(1);
} 	 

/******************************************************************************
*?  ?:uint8_t IIC_ReadByte(uint8_t ack)
*?  ?:IIC??????
*?  ?:ack=1 ?,????????? ack=0 ????????????
*???:?
*?  ?:??????
*******************************************************************************/	
uint8_t IIC_ReadByte(uint8_t ack)
{
	uint8_t i,receive=0;
	SDA_IN; //SDA??????? ??????????
    for(i=0;i<8;i++ )
	{
        IIC_SCL_L; 
        iic_delay(1);
        IIC_SCL_H;
        receive<<=1;
        if(IIC_SDA_READ)receive++; //???????
        iic_delay(1); 
    }					 
    if(ack)
        IIC_Ack(); //??ACK 
    else
        IIC_NAck(); //??nACK  
    return receive;
}

/******************************************************************************
*?  ?:uint8_t IIC_ReadByteFromSlave(uint8_t I2C_Addr,uint8_t addr)
*? ?:?????? ?????????
*?  ?:I2C_Addr  ??????
reg	     ?????
*buf      ??????????    
*???:?? 1?? 0??
*?  ?:?
*******************************************************************************/ 
uint8_t IIC_ReadByteFromSlave(uint8_t I2C_Addr,uint8_t reg,uint8_t *buf)
{
	IIC_Start();	
	IIC_SendByte(I2C_Addr);	 //??????
	if(IIC_WaitAck()) //??????????????
	{
		IIC_Stop();
		return 1;
	}
	IIC_SendByte(reg); //???????
	IIC_WaitAck();	  
	
	IIC_Start();
	IIC_SendByte(I2C_Addr+1); //??????			   
	IIC_WaitAck();
	*buf=IIC_ReadByte(0);	   
    IIC_Stop(); //????????
	return 0;
}

/******************************************************************************
*?  ?:uint8_t IIC_WriteByteFromSlave(uint8_t I2C_Addr,uint8_t addr,uint8_t buf))
*? ?:?????? ?????????
*?  ?:I2C_Addr  ??????
reg	     ?????
buf       ??????
*???:1 ?? 0??
*?  ?:?
*******************************************************************************/ 
uint8_t IIC_WriteByteToSlave(uint8_t I2C_Addr,uint8_t reg,uint8_t data)
{
	IIC_Start();
	IIC_SendByte(I2C_Addr); //??????
	if(IIC_WaitAck())
	{
		IIC_Stop();
		return 1; //????????
	}
	IIC_SendByte(reg); //???????
    IIC_WaitAck();	  
	IIC_SendByte(data); 
	if(IIC_WaitAck())
	{
		IIC_Stop(); 
		return 1; //??????
	}
	IIC_Stop(); //????????
    
    //return 1; //status == 0;
	return 0;
}

/******************************************************************************
*?  ?:uint8_t IICreadBytes(uint8_t dev, uint8_t reg, uint8_t length, uint8_t *data)
*? ?:?????? ?????? length??
*?  ?:dev     ??????
reg	   ?????
length  ??????
*data   ????????????
*???:1?? 0??
*?  ?:?
*******************************************************************************/ 
uint8_t IIC_ReadMultByteFromSlave(uint8_t dev, uint8_t reg, uint8_t length, uint8_t *data)
{
    uint8_t count = 0;
	uint8_t temp;
	IIC_Start();
	IIC_SendByte(dev); //??????
	if(IIC_WaitAck())
	{
		IIC_Stop(); 
		return 1; //????????
	}
	IIC_SendByte(reg); //???????
    IIC_WaitAck();	  
	IIC_Start();
	IIC_SendByte(dev+1); //??????	
	IIC_WaitAck();
    for(count=0;count<length;count++)
	{
		if(count!=(length-1))
            temp = IIC_ReadByte(1); //?ACK????
		else  
            temp = IIC_ReadByte(0); //??????NACK
        
		data[count] = temp;
	}
    IIC_Stop(); //????????
    //return count;
    return 0;
}

/******************************************************************************
*?  ?:uint8_t IICwriteBytes(uint8_t dev, uint8_t reg, uint8_t length, uint8_t* data)
*? ?:??????????? ?????
*?  ?:dev     ??????
reg	   ?????
length  ??????
*data   ?????????????
*???:1?? 0??
*?  ?:?
*******************************************************************************/ 
uint8_t IIC_WriteMultByteToSlave(uint8_t dev, uint8_t reg, uint8_t length, uint8_t* data)
{
    
 	uint8_t count = 0;
	IIC_Start();
	IIC_SendByte(dev); //??????
	if(IIC_WaitAck())
	{
		IIC_Stop();
		return 1; //????????
	}
	IIC_SendByte(reg); //???????
    IIC_WaitAck();	  
	for(count=0;count<length;count++)
	{
		IIC_SendByte(data[count]); 
		if(IIC_WaitAck()) //????????????
		{
			IIC_Stop();
			return 1; //??????
		}
	}
	IIC_Stop(); //????????
    
	return 0;
}

