/****************************************************************
 * @file            thread.c
 * @school          �ϲ����մ�ѧ��ʮ����ȫ����ѧ�����ܳ�����˫��������
 * @author          LYF/OREO
 * @version         v2.0
 * @Software        KEIL
 * @Target core     MM32F3277G
 * @date            2021-3-19
****************************************************************/
#include "thread.h"
#include "headfile.h"
GYRO_VAR gyroscope;
CON_VAR con_var;
#define SPEED_FILTER  5	// ���ٶȼ��˲����
int32 speed_data_filtering[SPEED_FILTER+1];
int uart_flag = 1;     //���ڱ�־λ
char uart1_get_buffer; //����1��������
int Left_TurnFlag=0;
int Right_TurnFlag=0;
int Stop_flag=0;
int go_flag=0;
unsigned char NUM_GET=0;
unsigned char ADD1_flag=0;
void task_2ms(void)
{
	//IMU���ݲɼ�
	Get_Imu_data(); 
    //s_motor.left.duty = (1*con_var.theory_duty-1*con_var.radius);
    //s_motor.right.duty = (1*con_var.theory_duty+1*con_var.radius);
    s_motor.left.duty = (1*580-1*con_var.radius);
    s_motor.right.duty = (1*580+1*con_var.radius);
    //���Ƶ��
    if(Left_TurnFlag==1)//��ת
        MotorOUT(-500,500);
    else if(Right_TurnFlag==1)//��ת
        MotorOUT(500,-500);
    else if(Stop_flag==1)//��ת
        MotorOUT(0,0);
    else if(go_flag==1)
        MotorOUT(500,500);
    else
        MotorOUT(s_motor.left.duty,s_motor.right.duty);
}
void task_4ms(void)
{   
    
    //�ٶȻ�
    con_var.theory_duty += PID_Increase(&s_pid.speed_pid, erect_speed, s_motor.speed.now, 2*s_motor.speed.set);
    con_var.theory_duty = limit_ab(con_var.theory_duty, -850, 850);//820
}
void task_8ms(void)
{	 
    //�������
    Mission_Control();
    //��̬����
    Get_Angle(2);
    //�������
    con_var.car_distance += ((float)s_motor.speed.now /10.0f);//��������2850
	//�ٶȻ����˲�
	con_var.turn_speed_min = data_filtering(speed_data_filtering, s_motor.speed.now,SPEED_FILTER);  
    //�ٶ��˲�
	con_var.turn_speed_min = limit_ab(con_var.turn_speed_min, 50, 160);//30  160
}
void task_40ms(void)
{		
    encoder_check();
	Flag_Check();
    Calcarr[0]=con_var.car_distance;        //����·��
    Calcarr[1]=gyroscope.Balance_Angle;     //ֱ���Ƕ�
	Calcarr[2]=gyroscope.Gyro_Turn;         //ת����ٶ� 
    Calcarr[3]=con_var.theory_duty;     
	Calcarr[4]=angle_x;	        //�ٶ�
    Calcarr[5]=speedL;              //ת��뾶
    Calcarr[6]=speedR;              //ת��뾶
	//send_to_computer();
}
//������
void task_20ms(void)
{

}
//������Ⱥ���
static schedule_task_t schedule_task[] =
{
    {task_2ms, 2, 2, 0},//task_2ms(�������� 2ִ������ 2��ʼ����ʱ�� 0 ����ִ�б�־
    {task_4ms, 4, 4, 0},
    {task_8ms, 8,  8, 0},
    {task_20ms, 20,  20, 0},
    {task_40ms, 40, 40, 0}
};

#define TASK_NUM (sizeof(schedule_task)/sizeof(schedule_task_t))
	
void task_interrupt(void)  
{
    unsigned char index = 0;
    for (index = 0; index < TASK_NUM; index++)
    {
        if (schedule_task[index].run_timer)
        {
            schedule_task[index].run_timer--;
            if (0 == schedule_task[index].run_timer)
            {
                schedule_task[index].run_timer = schedule_task[index].interval_time;
                schedule_task[index].run_sign = 1;
            }
        }
    }
}

void task_process(void)
{
    unsigned char index = 0;

    for (index = 0; index < TASK_NUM; index++)
    {
        if (schedule_task[index].run_sign)        
        {
            schedule_task[index].run_sign = 0;
            schedule_task[index].task_func();
        }
    }
}

int limit_ab(int x, int a, int b)
{
    if(x<a) x = a;
    if(x>b) x = b;
    return x;
}
