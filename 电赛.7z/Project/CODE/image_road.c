#include "image_road.h"
#include "headfile.h"
unsigned char ImageSide[PICH][2];
unsigned char Image_middle[PICH];
/**  ������  	  */
#define ROAD_MAIN_ROW     				20
/**  ʹ����ʼ�� */
#define ROAD_START_ROW   				50
/**  ʹ�ý����� */
#define ROAD_END_ROW      				20
/**  ������־λ */
unsigned char g_ucFlagRoundabout = 0;
/**  ʮ�ֱ�־λ */
unsigned char g_ucFlagCross  		 = 0;
/**  �����߱�־ */
unsigned char g_ucFlagZebra      = 0;
/**  ���߱�־ */
unsigned char  g_ucIsNoSide      = 0;
float image_Error                = 0;
/////////////////////////////////////////////////////////////////////////////
int Road_Loss_Count=0;
int cross_flag=0;
int coross_num=0;
/*
�ж��Ƿ���ֱ��
*/
unsigned char RoadIsStraight(unsigned char imageSide[LCDH][2])
{
    unsigned char i = 0;
    unsigned char leftState = 0, rightState = 0;
    
    /*������Ƿ񵥵�*/
    for(i = ROAD_START_ROW-1; i > ROAD_END_ROW; i--)
    {
        if(imageSide[i][0] + 5 < imageSide[i+1][0])
        {
            leftState = 1;
            break;
        }
    }
    
    /* �ұ����Ƿ񵥵�*/
    for(i = ROAD_START_ROW-1; i > ROAD_END_ROW; i--)
    {
        if(imageSide[i][1] - 5 > imageSide[i+1][1])
        {
            rightState = 1;
            break;
        }
    }
    
    if(leftState == 1 && rightState == 1)
    {
        return 1;
    }
    
    return 0;
}

/*
	�ж��Ƿ��ǰ�����
*/
unsigned char RoadIsZebra(unsigned char image[LCDH][LCDW], unsigned char *flag)
{
    int i = 0, j = 0;
    float count = 0;
    
    for(i = ROAD_MAIN_ROW - 2; i >  ROAD_MAIN_ROW + 2; i++)
    {
        for(j = 1; j < LCDW; j++)
        {
            if(image[i][j])//&& image[i][j-1] == 1)
            {
                count ++;
            }
        }
        //if(count > 4)
        //{
				//	
        //    *flag = 1;
        //    return 1;
        //}
    }
		Oled_Print_float_num(0,0,count);
    return 0;
}
/*
�ж��Ƿ���ʮ��
 0 ����  1 ��
*/
unsigned char RoadIsCross(unsigned char imageSide[LCDH][2], unsigned char *flag)
{
    int i = 0;
    unsigned char  rightState = 0;
    int start[5] = {0, 0, 0, 0, 0}, end[5] = {0, 0, 0, 0, 0};
    unsigned char count = 0;
    unsigned char index = 0;
    
    for(i = ROAD_START_ROW-1; i > ROAD_END_ROW; i--)
    {
        if(imageSide[i][1] == 119)
        {
            count++;  
        }
        else
        {
            if(count > 10 && index < 5)
            {
                start[index] = i + count;
                end[index]   = i;
                index++;
            }
            count = 0;
        }
        
    } 
    if(index > 1)
    {
        if(end[0] - start[1] > 10)
        {
            rightState = 1;
        }
    }
    index = 0;    
    if(rightState == 1)
    {
        for(i = ROAD_START_ROW-1; i > ROAD_END_ROW; i--)
        {
            if(imageSide[i][0] == 0)
            {
                count++;  
            }
            else
            {
                if(count > 10 && index < 5)
                {
                    start[index] = i + count;
                    end[index]   = i;
                    index++;
                }
                count = 0;
            }
            
        } 
        if(index > 1)
        {
            if(end[0] - start[1] > 10)
            {
                *flag = 1;
                return 1;
            }
        }
    }   
    return 0;
}

/*
�ж��Ƿ��ǻ���
*/
unsigned char RoadIsRoundabout(unsigned char image[LCDH][2], unsigned char *flag)
{
    int i = 0;
    unsigned char leftState = 0, rightState = 0;
    int start[5] = {0, 0, 0, 0, 0}, end[5] = {0, 0, 0, 0, 0};
    unsigned char count = 0;
    unsigned char index = 0;
    

    for(i = ROAD_START_ROW-1; i > ROAD_END_ROW; i--)
    {
        if(image[i][0] + 5 < image[i+1][0])
        {
            leftState = 1;
            break;
        }
    }
    

    for(i = ROAD_START_ROW-1; i > ROAD_END_ROW; i--)
    {
        if(image[i][1] - 5 > image[i+1][1])
        {
            rightState = 1;
            break;
        }
    }
    

    if(leftState == 0)
    {
        for(i = ROAD_START_ROW-1; i > ROAD_END_ROW; i--)
        {
            if(image[i][1] == 159)
            {
                count++;  
            }
            else
            {
                if(count > 10 && index < 5)
                {
                    start[index] = i + count;
                    end[index]   = i;
                    index++;
                }
                count = 0;
            }
            
        }
        
        if(index > 1)
        {
            if(end[0] - start[1] > 10)
            {
                *flag = 2;
                return 2;
            }
        }
    }
    

    if(rightState == 0)
    {
        for(i = ROAD_START_ROW-1; i > ROAD_END_ROW; i--)
        {
            if(image[i][0] == 0)
            {
                count++;  
            }
            else
            {
                if(count > 10 && index < 5)
                {
                    start[index] = i + count;
                    end[index]   = i;
                    index++;
                }
                count = 0;
            }
            
        }
        
        if(index > 1)
        {
            if(end[0] - start[1] > 10)
            {
                *flag = 1;
                return 1;
            }
        }
    }
    
    return 0;
}

/*
��ȡ��������
1 �󻷵�
2 �һ���
һ��ȫ����
*/
void RoundaboutGetSide(unsigned char imageInput[LCDH][LCDW], unsigned char imageSide[LCDH][2], unsigned char status)
{
    int i = 0, j = 0; 
    switch(status)
    {
      case 1:
        {
            for(i = ROAD_START_ROW; i > ROAD_END_ROW; i--)
            {
                for(j = LCDW/2; j > 0; j--)
                {
                    if(imageInput[i][j])
                    {
                        imageSide[i][0] = j;
                        break;
                    }
                }
            }
            break;
        }
        
      case 2:
        {
            for(i = ROAD_START_ROW; i > ROAD_END_ROW; i--)
            {
                for(j = LCDW/2; j < LCDW; j++)
                {
                    if(imageInput[i][j])
                    {
                        imageSide[i][1] = j;
                        break;
                    }
                }
            }
            break;
        }
    }
}

/*
�жϻ����Ƿ���ڻ���
1 �󻷵�
2 �һ���
*/
unsigned char RoundaboutGetArc(unsigned char imageSide[LCDH][2], unsigned char status, unsigned char* index)
{
    int i = 0; 
    unsigned char inc = 0, dec = 0;
    switch(status)
    {
      case 1:
        for(i = ROAD_START_ROW-1; i > ROAD_END_ROW; i--)
        {
            if(imageSide[i][0] != 0 && imageSide[i+1][0] != 0)
            {
                if(imageSide[i][0] >= imageSide[i+1][0])
                {
                    inc++;
                }
                else
                {
                    dec++;
                }
                
                /* �л��� */
                if(inc > 5 && dec > 5)
                {
                    *index = i + 5;
                    return 1;
                }
            }
            else
            {
                inc = 0;
                dec = 0;
            }
        }
        
        break;
        
      case 2:
        for(i = ROAD_START_ROW-1; i > ROAD_END_ROW; i--)
        {
            if(imageSide[i][1] != 119 && imageSide[i+1][1] != 119)
            {
                if(imageSide[i][1] > imageSide[i+1][1])
                {
                    inc++;
                }
                else
                {
                    dec++;
                }
                
                /* �л��� */
                if(inc > 5 && dec > 5)
                {
                    *index = i + 5;
                    return 1;
                }
            }
            else
            {
                inc = 0;
                dec = 0;
            }
        }
        
        break;
    }
    
    return 0;
}

//Ѱ�������
//1 ��߽�
//2 �ұ߽�
unsigned char ImageGetHop(uint8_t imageSide[LCDH][2], unsigned char state, unsigned char *x, unsigned char *y)
{
    int i = 0;
    unsigned char px = 0, py = 0;
    unsigned char count = 0;
    switch(state)
    {
      case 1:
        /* Ѱ������� */
        for(i = ROAD_START_ROW-1; i > ROAD_END_ROW; i--)
        {
            if(imageSide[i][0] == 0 && i > (ROAD_END_ROW + 5))
            {
                count++;
                
                if(count > 5)
                {
                    if(imageSide[i-1][0] > (imageSide[i][0] + 20))
                    {
                        py = i - 1;
                        px = imageSide[py][0];
                        break;
                    }
                    if(imageSide[i-2][0] > (imageSide[i-1][0] + 20))
                    {
                        py = i - 2;
                        px = imageSide[py][0];
                        break;
                    }
                    if(imageSide[i-3][0] > (imageSide[i-2][0] + 20))
                    {
                        py = i - 3;
                        px = imageSide[py][0];
                        break;
                    }
                    if(imageSide[i-4][0] > (imageSide[i-3][0] + 20))
                    {
                        py = i - 4;
                        px = imageSide[py][0];
                        break;
                    }       

                }
                
            }
            else
            {
                count = 0;
            }
        }
        
        if(py != 0)
        {
            *x = px;
            *y = py;
            return 1;
        }
        
        break;
        
        
      case 2:
        /* Ѱ������� */
        for(i = ROAD_START_ROW-1; i > ROAD_END_ROW; i--)
        {
            if(imageSide[i][1] == 119 && i > (ROAD_END_ROW + 5))
            {
                count++;
                
                if(count > 5)
                {
                    if(imageSide[i-1][1] < (imageSide[i][1] - 20))
                    {
                        py = i - 1;
                        px = imageSide[py][1];
                        break;
                    }
                    if(imageSide[i-2][1] < (imageSide[i-1][1] - 20))
                    {
                        py = i - 2;
                        px = imageSide[py][1];
                        break;
                    }
                    if(imageSide[i-3][1] < (imageSide[i-2][1] - 20))
                    {
                        py = i - 3;
                        px = imageSide[py][1];
                        break;
                    }
                    if(imageSide[i-4][1] < (imageSide[i-3][1] - 20))
                    {
                        py = i - 4;
                        px = imageSide[py][1];
                        break;
                    }       

                }
                
            }
            else
            {
                count = 0;
            }
        }
        
        if(py != 0)
        {
            *x = px;
            *y = py;
            return 1;
        }     
        break;
    }
    return 0;
}

/*
���ߴ���
1 ����� ����
2 �ұ��� ����
startX ��ʼ����
startY ��ʼ����
endX	 ��������
endY   ��������
*/
void ImageAddingLine(unsigned char imageSide[LCDH][2], unsigned char status, unsigned char startX, unsigned char startY, unsigned char endX, unsigned char endY)
{
    int i = 0; 
    
    /* x = ky + b */
    float k = 0.0f, b = 0.0f;
    switch(status)
    {
      case 1:
        {
            k = (float)((float)endX - (float)startX) / (float)((float)endY - (float)startY);
            b = (float)startX - (float)startY * k;
            
            for(i = startY; i < endY; i++)
            {
                imageSide[i][0] = (unsigned char)(k * i + b);
            }
            break;
        }
        
      case 2:
        {
            k = (float)((float)endX - (float)startX) / (float)((float)endY - (float)startY);
            b = (float)startX - (float)startY * k;
            
            for(i = startY; i < endY; i++)
            {
                imageSide[i][1] = (unsigned char)(k * i + b);
            }
            break;
        }
        
    }
}


void RoundaboutProcess(unsigned char imageInput[LCDH][LCDW], unsigned char imageSide[LCDH][2], unsigned char* state)
{
    int i = 0;
    unsigned char pointX = 0, pointY = 0;
    unsigned char err = 0;
    static unsigned char cnt = 0;
    switch(*state)
    {
        /* ????? ??????? */
      case 1:
        
        /* ??????? */
        RoundaboutGetSide(imageInput, imageSide, 1);
        
        /* ???? */
        err = RoundaboutGetArc(imageSide, 1, &pointY);
        
        /* ??? ???? ??????? ? ????? */
        if(err)
        {
            pointX = imageSide[pointY][0];
            
            /* ????? */
            if((pointY + 10) > ROAD_MAIN_ROW)
            {
                * state = 3;
            }
        }
        else
        {
            pointY = ROAD_START_ROW-1;
            
            /* ???? ???? ??????? ? ????? */
            for(i = ROAD_START_ROW-1; i > ROAD_END_ROW; i--)
            {
                if(imageSide[i][0] > imageSide[pointY][0])
                {
                    pointY = i;
                }
            }
            
            pointX = imageSide[pointY][0];
        }
        
        /* ?? */
        ImageAddingLine(imageSide, 1, pointX, pointY, 0, ROAD_START_ROW);
        
        break;
        
        /* ????? ??????? */
      case 2:

        * state = 0;
        break;
         
        
        /* ??????, ?????? */
      case 3:
        pointY = ROAD_START_ROW-1;
        
        /* ??????? */
        RoundaboutGetSide(imageInput, imageSide, 1);
        
        /* ???? */
        err = RoundaboutGetArc(imageSide, 1, &pointY);
        
        /* ??? ???? ??????? ? ????? */
        if(err)
        {
            pointX = imageSide[pointY][0];
            
            if((pointY + 10) > ROAD_MAIN_ROW)
            {
                /* ?????? */
                ImageAddingLine(imageSide, 1, pointX, pointY, 0, ROAD_START_ROW);
            }
        }
        
        /* ?????? */
        pointX = LCDW/3;
        pointY = ROAD_START_ROW-1;
        
        /* ????? */
        ImageGetHop(imageSide, 1, &pointX, &pointY);
        
        if(pointY >= ROAD_MAIN_ROW && pointY != ROAD_START_ROW-1)
        {
            imageSide[ROAD_MAIN_ROW][0] = 0;
            * state = 5;
        }
        
        /* ?? */
        ImageAddingLine(imageSide, 2, pointX+30, pointY, (LCDW - 1), ROAD_START_ROW);
        
        break;
        
      case 4:
        
        break;
        
        /* ???, ????? */
      case 5:
        
        
        /* ???? */
        err = RoundaboutGetArc(imageSide, 2, &pointY);
        
        if(err || cnt)
        {
            cnt++;
            
            imageSide[ROAD_MAIN_ROW][0] = 0;
            imageSide[ROAD_MAIN_ROW][1] = LCDW/3; 
        }
        
        if(cnt > 20)
        {
            cnt = 0;
            * state = 0;

        }
        
        break;
        
          /* ???, ????? */
      case 6:
         
        break;    
    
    }
}


//��ȡʮ�ֱ���
//��Ϊʮ���м�� ���Դ��м�������ɨ��
void CrossGetSide(unsigned char imageInput[LCDH][LCDW], unsigned char imageSide[LCDH][2])
{
    int i = 0, j = 0;
    
    for(i = ROAD_START_ROW-1; i > ROAD_END_ROW; i--)
    {
        for(j = 60; j > 1; j--)
        {
            if(imageInput[i][j])
            {
                imageSide[i][0] = j;
                break;
            }
        }       
        
        for(j = 60; j < 119; j++)
        {
            if(imageInput[i][j])
            {
                imageSide[i][1] = j;
                break;
            }
        }
    }

}
//ʮ�ִ���
//1 ����ʮ��
//2 ����ʮ��
//3 ��ʮ��
void CrossProcess(unsigned char imageInput[LCDH][LCDW], unsigned char imageSide[LCDH][2], unsigned char* state)
{

    unsigned char pointX = 0, pointY = 0;
    unsigned char leftIndex = 0;
    static unsigned char count  = 0;
    switch(*state)
    {
      case 1://����ʮ��
        {
            //���»�ȡ����
            CrossGetSide(imageInput, imageSide);
            
            //Ѱ�������        
            if(ImageGetHop(imageSide, 1, &pointX, &pointY))
            {
                /* ���� */
                ImageAddingLine(imageSide, 1, pointX, pointY, 0, ROAD_START_ROW);   
            }
            
            leftIndex = pointY;
            pointX = 0;
            pointY = 0;
            
            /* Ѱ������� */          
            if(ImageGetHop(imageSide, 2, &pointX, &pointY))
            {
                /* ���� */
                ImageAddingLine(imageSide, 2, pointX, pointY, (LCDW - 1), ROAD_START_ROW);   
            }
            
            if(leftIndex != 0 && pointY != 0 && leftIndex >= ROAD_MAIN_ROW && pointY >= ROAD_MAIN_ROW)
            {
                * state = 2;
                count = 0;
            }
            
            if(count++ > 40)//��⵽����תʱ��
            {
                * state = 2;
                count = 0;
            }
        
            break;
        }
        
      case 2://����ʮ��
        {
            
            /* ��黡�� */
            if(RoundaboutGetArc(imageSide, 1, &leftIndex))
            {
                /* ����ȷ���߽� */
                RoundaboutGetSide(imageInput, imageSide, 1);
                
                if(ImageGetHop(imageSide, 1, &pointX, &pointY))
                {
                    /* ���� */
                    ImageAddingLine(imageSide, 1, pointX, pointY, imageSide[leftIndex][0], leftIndex);   
                    
                    * state = 3;
                    
                    count = 0;
                }
                else
                {
                    imageSide[ROAD_MAIN_ROW][0] = LCDW/2;
                    imageSide[ROAD_MAIN_ROW][1] = LCDW - 1;
                }
            }
           
            break;
        }
        
      case 3://��ʮ��
        {
            
            /* ����ȷ���߽� */
            RoundaboutGetSide(imageInput, imageSide, 1);
					
            if(ImageGetHop(imageSide, 1, &pointX, &pointY))
            {
                /* ��黡�� */
                if(RoundaboutGetArc(imageSide, 1, &leftIndex))
                { 
                   /* ���� */
                    ImageAddingLine(imageSide, 1, pointX, pointY, imageSide[leftIndex][0], leftIndex); 
                }
                else
                {
                    /* ���� */
                    ImageAddingLine(imageSide, 1, pointX, pointY, 0, ROAD_START_ROW); 
                }
                
                if(pointY >= ROAD_MAIN_ROW)
                {
                    * state = 0;
                    count = 0;
                }
            }
            else
            {
                imageSide[ROAD_MAIN_ROW][0] = 90;
                imageSide[ROAD_MAIN_ROW][1] = LCDW - 1;
            }
            
            if(count++ > 10)
            {
                *state = 0;
                count = 0;
            }
            
            break;
        }
    }

}
//�����ߴ���ͣ��
//ѡ������ͣ��
void ZebraProcess(unsigned char imageSide[LCDH][2], unsigned char state)
{
    static uint16_t count = 0; 
    
    count++;
    
    if(state == 1)
    {
        imageSide[ROAD_MAIN_ROW][0] = 0;
        imageSide[ROAD_MAIN_ROW][1] = LCDW/2;
    }
    else
    {
        imageSide[ROAD_MAIN_ROW][0] = LCDW/2;
        imageSide[ROAD_MAIN_ROW][1] = LCDW - 1;
    }
    
    if(count > 100)
    {
        //while(1);
    }
    
}
int COROSSL_X=0;
int COROSSL_Y=0;
int COROSSR_X=0;
int COROSSR_Y=0;

float left_x=10;
float left_y=34;

float Right_X=100;
float Right_Y=34;

float k1=0;
float b1=0;

float k2=0;
float b2=0;
void Coross_processing(void)
{
    int i;
    if(Road_Loss_Count>7 && psInductance->corss_flag==0 &&psInductance->ThreeFlag==0  && psInductance->RoundFlag==0)
    {
        coross_num++;
        psInductance->corss_flag=1;
    }
    if(psInductance->corss_flag==1)
    {
        for(i=60;i>0;i--)
        {
            if(Pixle[5][i]==0)
            {
                left_x=i;
                left_y=5;
                break;
            }
            
        }
        for(i=60;i<120;i++)
        {
            if(Pixle[5][i]==0)
            {
                Right_X=i;
                Right_Y=5;
                break;
            }
            
        }
       COROSSL_X=18;
       COROSSL_Y=34;
       COROSSR_X=102;
       COROSSR_Y=34;
       k1=(left_x-COROSSL_X)/(left_y-COROSSL_Y);
       b1=-k1*left_y+left_x;
       k2=(Right_X-COROSSR_X)/(Right_Y-COROSSR_Y);
       b2=-k2*Right_Y+Right_X;
       if(Road_Loss_Count<2)//
       {
            psInductance->corss_flag=0;
       }
    }
    Road_Loss_Count=0;
}
//����dir��ʼ��
float RoadGetSteeringError(uint8_t imageSide[PICH][2], uint8_t lineIndex)
{
    int i;
    float sum=0;
    float pic_dir=0;
    if(psInductance->Third__turn1Flag==1)
    {
        for(i=40;i>=35;i--)//27 17
        {
            sum+=ImageSide[i][0]+ImageSide[i][1]-120;//ƫ��ͼ�
        }
        pic_dir=sum/6;
    }
    else
    {
        for(i=45;i>=40;i--)//27 17
        {
            sum+=ImageSide[i][0]+ImageSide[i][1]-120;//ƫ��ͼ�
        }
        pic_dir=sum/6;
    }

    return pic_dir;
}



//59���ж϶���
//0 û�ж��� 1 ��߶��� 2�ұ߶��� 3���Ҷ����� 4 ����
unsigned char pstart_flag=0;
unsigned char RoadIsNoSide(unsigned char imageInput[LCDH][LCDW], unsigned char imageOut[PICH][2], unsigned char lineIndex,unsigned char scan_begin)
{
    unsigned char state = 0;
	unsigned char last;
    int get_flag=0;
    int i = 0; 
    if(pstart_flag==0)
		last =59,pstart_flag=1;
	else
		last = scan_begin;
    imageOut[lineIndex-1][0] = 0;
    imageOut[lineIndex-1][1] = 119;
    if(imageInput[lineIndex-1][0]==0)
    {
     imageOut[lineIndex-1][1] = 2;   
    for(i = 119; i > 1; i--)
    {
        if(imageInput[lineIndex-1][i]==0)
        {
            imageOut[lineIndex-1][1] = i;
            break;
        }
    }
    }
    else if(imageInput[lineIndex-1][119]==0)
    {
    imageOut[lineIndex-1][1] = 118;
    for(i = 0; i < 119; i++)
    {
        if(imageInput[lineIndex-1][i]==0)
        {
            imageOut[lineIndex-1][0] = i;
            break;
        }
    }
    }
    else
    {
    for(i = 119; i > 0; i--)
    {
        if(imageInput[lineIndex-1][i]==0)
        {
            imageOut[lineIndex-1][1] = i;
            break;
        }
    }
    for(i = 0; i <119; i++)
    {
        if(imageInput[lineIndex-1][i]==0)
        {
            imageOut[lineIndex-1][0] = i;
            break;  
        }
    } 
    }
    Image_middle[lineIndex-1]=(imageOut[lineIndex-1][0]+imageOut[lineIndex-1][1])/2;
    
//////////û��///////////////////////////////////////////////////////////////////
    if(i == 1)
    {
        /* ��߽綪�� */
        state = 1;	
    }
    if(i == 119)
    {
        /* ���ұ߽綪�� */
        if(state == 1)
        {
            state = 3;
        }
        /* �ұ߽綪�� */
        else
        {
            state = 2; 
        } 
    }
    if(imageOut[lineIndex][1] <= imageOut[lineIndex][0])
    {		
		/* ���� */
        state = 4; 
    }
    return state;
}

void RoadNoSideProcess(uint8_t imageInput[LCDH][LCDW], uint8_t imageOut[LCDH][2], uint8_t mode, int lineIndex)
{
    int i = 0, j = 0, count = 0; 
    
    switch(mode)
    {
      case 1:
        for(i = imageOut[lineIndex][1]; i > 1; i--)
        {
            count++;
            for(j = lineIndex; j > ROAD_END_ROW && lineIndex > count; j--)
            {
                if(imageInput[j][i])
                {
                    imageOut[lineIndex - count][0] = 0;
                    imageOut[lineIndex - count][1] = i;
                    break;
                }
                
            }
        }
        break;
        
        
      case 2:
        for(i = imageOut[lineIndex][0]; i < 119; i++)
        {
            count++;
            for(j = lineIndex; j > ROAD_END_ROW && lineIndex > count; j--)
            {
                if(imageInput[j][i])
                {
                    imageOut[lineIndex - count][0] = i;
                    imageOut[lineIndex - count][1] = 119;
                    break;
                }
                
            }
        }
        break;
    
    }
    
}

//Ѱ�ұ���
unsigned char ImageGetSide(unsigned char imageInput[LCDH][LCDW], unsigned char imageOut[PICH][2])
{
    int i = 0;
    RoadIsNoSide(imageInput, imageOut, ROAD_START_ROW,Image_middle[47]); 
    for(i = ROAD_START_ROW-2; i > ROAD_END_ROW; i--)
    {
        imageOut[i][0] = 0;
        imageOut[i][1] = 119;
        int j;
        
        for(j = Image_middle[i+1]; j<Image_middle[i+1]+6; j++)
        {
            if(imageInput[i][j]==0)
            {
                imageOut[i][1] = j;
                break;
            }
        }
        for(j = Image_middle[i+1]; j > imageOut[i+1][0]-6; j--)
        {
            if(imageInput[i][j]==0)
            {
                imageOut[i][0] = j;
                break;
            }
        }
        Image_middle[i]=(imageOut[i][0]+imageOut[i][1])/2;
    } 
    return 0;
}

void ImagePortFilter(unsigned char imageInput[LCDH][LCDW], unsigned char imageOut[LCDH][LCDW])
{
    unsigned char temp = 0;
    
    for(int i = 1; i < LCDH - 1; i++)
    {
        for(int j = 1; j < LCDW - 1; j++)
        {
            temp = imageInput[i-1][j-1] + imageInput[i-1][j] + imageInput[i-1][j+1] + 
                   imageInput[i  ][j-1] + imageInput[i  ][j] + imageInput[i  ][j+1] + 
                   imageInput[i+1][j-1] + imageInput[i+1][j] + imageInput[i+1][j+1];
            
            if(temp > 7)
            {
                imageOut[i][j] = 1;
            }
            else
            {
                imageOut[i][j] = 0;
            }
        
        }
    }
}

void Write_MidRoad(void)
{   
    int i;
    for(i=0;i<LCDW;i++)
	{
		Pixle[45][i]=0;//45��
	}
    for(i=0;i<LCDW;i++)
	{
		Pixle[40][i]=0;//40��
	}
    for(i=0;i<LCDW;i++)
	{
		Pixle[20][i]=0;//20��
	}
	//int i;
    //int l1;
    //int l2;
	//memset(Pixle, 1, LCDH*LCDW);
	//for(i=0;i<35;i++)
	//{
		//Pixle[i][Image_middle[i]]=0;//������
		//Pixle[i][ImageSide[i][0]]=0;//�����
		//Pixle[i][ImageSide[i][1]]=0;//���ұ�
	//}
    /*
	for(i=0;i<50;i++)
	{
        l1=k1*i+b1;
        l2=k2*i+b2;
        if(psInductance->corss_flag!=0)
        { 
            Pixle[i][l1]=0;
            Pixle[i][l2]=0;
        }
	}
	}*/
}
void get_ten_road(void)
{
    int i,j;
    int sum=0;
    if(psInductance->corss_flag==0)
    {
        for(i=40;i<44;i++)
        {
            for(j=0;j<120;j=j+10)
            {
                if(Pixle[i][j]==0)
                    sum++;
            }
        }
        if(sum>30)
            psInductance->corss_flag=1;
    }
}
void get_Middle(void)
{
    int i,j;
    int sum=0;
    if(psInductance->middle_flag==0)
    {
        for(i=30;i<50;i++)
        {
            for(j=40;j<80;j=j+2)
            {
                if(Pixle[i][j]==0)
                    sum++;
            }
        }
        Calcarr[5]=sum;
        if(sum>120)
            psInductance->middle_flag=1;
    }
}
void ImageProcess(void)
{
    int i,sum;
    sum=0;
    if(mt9v03x_finish_flag)
    { 
		
		Get_Use_Image();
    	Get_Bin_Image(0);
        Bin_Image_Filter();
        ImageGetSide(Pixle,ImageSide); //��50 ��120
        image_Error = -RoadGetSteeringError(ImageSide,20);
        get_ten_road();
        get_Middle();
        Oled_Print_float_num(0,0,image_Error);
        Oled_Print_float_num(0,1,NUM_GET);
        Oled_Print_float_num(0,2,mission_number);
        con_var.radius = -PID_PositionDynamic(&s_pid.turn_pid, erect_turn[0],image_Error, 0);
        con_var.radius = limit_ab(con_var.radius,-800,800);//70
        //����ģʽ ������ͷͼ��
        if(Road_Integrals.Test_Mode==1)
        {        
            Oled_Print_float_num(30,0,ImageSide[45][0]);
            Oled_Print_float_num(60,0,ImageSide[45][1]);
            Write_MidRoad();
      	    OLED_Road(LCDH, LCDW, (unsigned char *)Pixle);
        }
      	// OLED��̬��ʾ����ͷͼ��
        mt9v03x_finish_flag=0;
	}
}