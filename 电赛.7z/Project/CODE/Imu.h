#ifndef _IMU_h
#define _IMU_h
extern void Get_Imu_data(void);
extern void Get_Angle(int way);
extern float data_filtering(long  int *filter_arr,const short int filter_data, const unsigned char filter_depth);
extern void get_angle_xyz();
extern float angle_x;
extern float angle_y;
extern float angle_z;
#endif