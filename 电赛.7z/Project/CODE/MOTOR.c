/****************************************************************
 * @file            MOTOR.c
 * @school          �ϲ����մ�ѧ��ʮ����ȫ����ѧ�����ܳ�����˫��������
 * @author          LYF/OREO
 * @version         v2.0
 * @Software        KEIL
 * @Target core     MM32F3277G
 * @date            2021-3-19
****************************************************************/
#include "MOTOR.h"
#include "headfile.h"
#define       SpeedPWMMax                        800    
#define       MotorOUTMax                        8500
#define       MotorOUTMin                        -8500
#define       Left_moto_ratio                    1
#define       Right_moto_ratio                   1
Motor s_motor;
short speedL=0;
short speedR=0;
/*
 * ���Ҳ��ٷ���
 */
static void dir_encoder_analyze(MotorDir *dir)
{
    if (dir->acc > 300)
    {
        dir->status = 1;
    }
    if (dir->speed > (s_motor.speed.set + 300))
    {
        dir->status = 2;
    }
    if (dir->speed < -300)
    {
        dir->status = -1;
    }

    if (dir->status)
    {
        if (dir->acc <= 300)
        {
            if (dir->speed < (s_motor.speed.set + 300) && dir->speed > 0)
            {
                dir->status = 0;
            }
        }
    }

    if (!dir->status)
    {
        dir->speed = dir->speed*0.9 + dir->speed_last*0.1;
        dir->speed_last = dir->speed;
    }
    else
    {
        dir->speed = dir->speed*0.5 + dir->speed_last*0.5;
        dir->speed_last = dir->speed;
    }
}

static void speed_analyze(Motor *motor)
{
    static short int StatusCount = 0;
    if ((motor->left.status && motor->right.status)
        || (motor->left.status && motor->right.speed < 20)
        || (motor->right.status && motor->left.speed < 20))
    {
        StatusCount++;

        if (StatusCount >= 100)
        {
            StatusCount = 0;

        }
    }
    if (motor->left.status && motor->right.status)
    {
        motor->speed.now = motor->speed.last;
    }
    else if (motor->left.status)
    {
        if (motor->right.speed > motor->speed.set)
        {
            motor->speed.now = motor->speed.last;
        }
        else
        {
            motor->speed.now = motor->right.speed;
        }
    }
    else if (motor->right.status)
    {
        if (motor->left.speed > motor->speed.set)
        {
            motor->speed.now = motor->speed.last;
        }
        else
        {
            motor->speed.now = motor->left.speed;
        }
    }
    else
    {
        motor->speed.now = (motor->left.speed + motor->right.speed) / 2;
    }
    motor->speed.now = motor->speed.now*0.8 + motor->speed.last*0.2;
    motor->speed.last = motor->speed.now;
}

void encoder_check(void)
{
    s_motor.left.speed = Get_BMQL();
    speedL=s_motor.left.speed;
    s_motor.left.acc = s_motor.left.speed - s_motor.left.speed_last;
    dir_encoder_analyze(&s_motor.left);
	s_motor.right.speed=Get_BMQR();
    speedR=s_motor.right.speed;
    s_motor.right.acc = s_motor.right.speed - s_motor.right.speed_last;
    dir_encoder_analyze(&s_motor.right);
    speed_analyze(&s_motor);
	s_motor.speed.turn_min = s_motor.speed.turn_min * 0.1 + s_motor.speed.now * 0.9;
	if(s_motor.speed.turn_min<40)
		s_motor.speed.turn_min=40;
}
void  MotorOUT( int LMotor_OUT, int RMotor_OUT)
 {
    int LMOTOROUT=LMotor_OUT*10*Left_moto_ratio;
    int RMOTOROUT=-RMotor_OUT*10*Right_moto_ratio;

  	if(LMOTOROUT>MotorOUTMax) LMOTOROUT=MotorOUTMax;
  	if(RMOTOROUT>MotorOUTMax) RMOTOROUT=MotorOUTMax;

  	if(LMOTOROUT<MotorOUTMin) LMOTOROUT=MotorOUTMin;
  	if(RMOTOROUT<MotorOUTMin) RMOTOROUT=MotorOUTMin;

  	if(LMOTOROUT<0)
  	{   
			LMOTOROUT = -LMOTOROUT;
			pwm_duty_updata(TIM_2,TIM_2_CH2_A01,500);
			pwm_duty_updata(TIM_2,TIM_2_CH1_A00,LMOTOROUT);
  	}
  	else
  	{
			pwm_duty_updata(TIM_2,TIM_2_CH2_A01,LMOTOROUT);
			pwm_duty_updata(TIM_2,TIM_2_CH1_A00,500);
  	}

  	if(RMOTOROUT>0)
  	{
		  pwm_duty_updata(TIM_2,TIM_2_CH4_A03,500);
			pwm_duty_updata(TIM_2,TIM_2_CH3_A02,RMOTOROUT);
  	}
  	else
  	{
  	  RMOTOROUT = -RMOTOROUT;
			pwm_duty_updata(TIM_2,TIM_2_CH4_A03,RMOTOROUT);
			pwm_duty_updata(TIM_2,TIM_2_CH3_A02,500);
  	}
}
